package com.mzenix.deckhome

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

// ------------------------------------------------------------------ Model

data class AppItem(
    val label: String,
    val pkg: String,
    val icon: ImageBitmap,
    val tint: Color,
    val isGame: Boolean
)

data class HomeState(
    val musicOn: Boolean,
    val track: Int,
    val customName: String?,
    val favorites: Set<String>,
    val bgMode: Int,
    val bgImage: ImageBitmap?,
    val accent: Int,
    val avatar: Int
)

class HomeActions(
    val toggleMusic: () -> Unit,
    val chooseTrack: (Int) -> Unit,
    val pickMusic: () -> Unit,
    val toggleFav: (String) -> Unit,
    val chooseBg: (Int) -> Unit,
    val pickPhoto: () -> Unit,
    val chooseAccent: (Int) -> Unit,
    val chooseAvatar: (Int) -> Unit,
    val sfx: (Int) -> Unit,
    val exitApp: () -> Unit
)

private val ACCENTS = listOf(
    Color(0xFFFFC629), // yellow
    Color(0xFFFF4D4D), // red
    Color(0xFF34D96B), // green
    Color(0xFF3D9BFF), // blue
    Color(0xFFFF5FA8), // pink
    Color(0xFFA66BFF), // purple
    Color(0xFF25E3E3)  // cyan
)
private val ACCENT_NAMES = listOf("YELLOW", "RED", "GREEN", "BLUE", "PINK", "PURPLE", "CYAN")
private val AVATAR_NAMES = listOf(
    "Girl - smile", "Little Knight", "Space Soldier", "Smiley", "Happy Plumber", "None"
)

private val accentState = mutableStateOf(ACCENTS[0])
private val Gold: Color get() = accentState.value
private val Panel = Color(0xFF111112)
private val TextDim = Color(0xFF9A9A9A)
private val Ink = Color(0xFF050505)

private const val SFX_MOVE = 0
private const val SFX_CLICK = 1
private const val SFX_OPEN = 2
private const val SFX_POP = 3

// ------------------------------------------------------------------ Activity

class MainActivity : ComponentActivity() {

    private var player: MediaPlayer? = null
    private var sounds: SoundPool? = null
    private var sMove = 0
    private var sClick = 0
    private var sOpen = 0
    private var sPop = 0
    private val trackRes = intArrayOf(
        R.raw.ambient, R.raw.music_dawn, R.raw.music_midnight, R.raw.music_glow
    )

    private var musicOn by mutableStateOf(true)
    private var favorites by mutableStateOf(setOf<String>())
    private var bgMode by mutableIntStateOf(0)
    private var bgImage by mutableStateOf<ImageBitmap?>(null)
    private var trackIdx by mutableIntStateOf(0)
    private var customName by mutableStateOf<String?>(null)
    private var accentIdx by mutableIntStateOf(0)
    private var avatarIdx by mutableIntStateOf(0)
    private val prefs by lazy { getSharedPreferences("deckhome", MODE_PRIVATE) }

    private val photoPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: Exception) { }
                val img = loadBg(uri)
                if (img != null) {
                    bgImage = img
                    prefs.edit().putString("bg_uri", uri.toString()).apply()
                    changeBgMode(2)
                }
            }
        }

    private val musicPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: Exception) { }
                val name = queryName(uri)
                prefs.edit()
                    .putString("custom_uri", uri.toString())
                    .putString("custom_name", name)
                    .apply()
                customName = name
                chooseTrack(4)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        musicOn = prefs.getBoolean("music", true)
        favorites = prefs.getStringSet("fav", emptySet())?.toSet() ?: emptySet()
        bgMode = prefs.getInt("bg_mode", 0)
        prefs.getString("bg_uri", null)?.let { bgImage = loadBg(Uri.parse(it)) }
        trackIdx = prefs.getInt("track", 0)
        customName = prefs.getString("custom_name", null)
        accentIdx = prefs.getInt("accent", 0).coerceIn(0, ACCENTS.lastIndex)
        accentState.value = ACCENTS[accentIdx]
        avatarIdx = prefs.getInt("avatar", 0).coerceIn(0, AVATAR_NAMES.lastIndex)

        initSounds()
        loadTrack(play = false)

        val apps = loadApps()
        val actions = HomeActions(
            toggleMusic = { toggleMusic() },
            chooseTrack = { chooseTrack(it) },
            pickMusic = { musicPicker.launch(arrayOf("audio/*")) },
            toggleFav = { toggleFavorite(it) },
            chooseBg = { changeBgMode(it) },
            pickPhoto = { photoPicker.launch(arrayOf("image/*")) },
            chooseAccent = { chooseAccent(it) },
            chooseAvatar = { chooseAvatar(it) },
            sfx = { sfx(it) },
            exitApp = { finish() }
        )
        setContent {
            DeckHome(
                apps = apps,
                st = HomeState(
                    musicOn = musicOn,
                    track = trackIdx,
                    customName = customName,
                    favorites = favorites,
                    bgMode = bgMode,
                    bgImage = bgImage,
                    accent = accentIdx,
                    avatar = avatarIdx
                ),
                act = actions
            )
        }
    }

    override fun onStart() {
        super.onStart()
        if (musicOn) player?.start()
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release(); player = null
        sounds?.release(); sounds = null
    }

    // ---- audio ----

    private fun initSounds() {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        sounds = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build().also {
            sMove = it.load(this, R.raw.sfx_move, 1)
            sClick = it.load(this, R.raw.sfx_click, 1)
            sOpen = it.load(this, R.raw.sfx_open, 1)
            sPop = it.load(this, R.raw.sfx_pop, 1)
        }
    }

    private fun loadTrack(play: Boolean) {
        player?.release()
        player = null
        var p: MediaPlayer? = null
        if (trackIdx == 4) {
            val u = prefs.getString("custom_uri", null)
            if (u != null) {
                p = try {
                    MediaPlayer().apply {
                        setDataSource(this@MainActivity, Uri.parse(u))
                        prepare()
                    }
                } catch (e: Exception) {
                    null
                }
            }
        }
        if (p == null) {
            if (trackIdx == 4) trackIdx = 0
            p = MediaPlayer.create(this, trackRes[trackIdx.coerceIn(0, trackRes.lastIndex)])
        }
        p?.isLooping = true
        p?.setVolume(0.35f, 0.35f)
        player = p
        if (play) p?.start()
    }

    private fun chooseTrack(i: Int) {
        trackIdx = i
        prefs.edit().putInt("track", i).apply()
        loadTrack(play = musicOn)
    }

    private fun toggleMusic() {
        musicOn = !musicOn
        prefs.edit().putBoolean("music", musicOn).apply()
        if (musicOn) player?.start() else player?.pause()
    }

    private fun sfx(kind: Int) {
        val id = when (kind) {
            SFX_MOVE -> sMove
            SFX_OPEN -> sOpen
            SFX_POP -> sPop
            else -> sClick
        }
        sounds?.play(id, 0.8f, 0.8f, 1, 0, 1f)
    }

    // ---- settings ----

    private fun toggleFavorite(pkg: String) {
        favorites = if (pkg in favorites) favorites - pkg else favorites + pkg
        prefs.edit().putStringSet("fav", HashSet(favorites)).apply()
    }

    private fun changeBgMode(mode: Int) {
        bgMode = mode
        prefs.edit().putInt("bg_mode", mode).apply()
    }

    private fun chooseAccent(i: Int) {
        val v = i.coerceIn(0, ACCENTS.lastIndex)
        accentIdx = v
        accentState.value = ACCENTS[v]
        prefs.edit().putInt("accent", v).apply()
    }

    private fun chooseAvatar(i: Int) {
        avatarIdx = i
        prefs.edit().putInt("avatar", i).apply()
    }

    private fun queryName(uri: Uri): String = try {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (col >= 0 && c.moveToFirst()) c.getString(col) else null
        } ?: "Custom track"
    } catch (e: Exception) {
        "Custom track"
    }

    private fun loadBg(uri: Uri): ImageBitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 2000 || bounds.outHeight / sample > 2000) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?.asImageBitmap()
    } catch (e: Exception) {
        null
    }

    @Suppress("DEPRECATION")
    private fun loadApps(): List<AppItem> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                val bmp = it.loadIcon(pm).toBitmap(192, 192)
                val px = Bitmap.createScaledBitmap(bmp, 1, 1, true).getPixel(0, 0)
                val ai = it.activityInfo.applicationInfo
                AppItem(
                    label = it.loadLabel(pm).toString(),
                    pkg = it.activityInfo.packageName,
                    icon = bmp.asImageBitmap(),
                    tint = Color(0xFF000000.toInt() or (px and 0xFFFFFF)),
                    isGame = ai.category == ApplicationInfo.CATEGORY_GAME ||
                        (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                )
            }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }
}

// ------------------------------------------------------------------ Helpers

private fun fmt(pattern: String): String =
    SimpleDateFormat(pattern, Locale.getDefault()).format(Date())

private fun hideKeyboard(v: View) {
    (v.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        .hideSoftInputFromWindow(v.windowToken, 0)
}

@Composable
fun rememberBattery(): Int {
    val ctx = LocalContext.current
    var level by remember { mutableIntStateOf(-1) }
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                if (l >= 0 && s > 0) level = l * 100 / s
            }
        }
        val sticky = ContextCompat.registerReceiver(
            ctx, receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        sticky?.let { receiver.onReceive(ctx, it) }
        onDispose { ctx.unregisterReceiver(receiver) }
    }
    return level
}

// ------------------------------------------------------------------ Home

@Composable
fun DeckHome(apps: List<AppItem>, st: HomeState, act: HomeActions) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val haptic = LocalHapticFeedback.current
    val tabs = listOf("ALL", "FAV", "GAMES", "APPS")
    var tab by remember { mutableIntStateOf(0) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var settingsOpen by remember { mutableStateOf(false) }
    var exitOpen by remember { mutableStateOf(false) }
    var stage by remember { mutableIntStateOf(0) } // 0 intro, 1 welcome, 2 home
    val favorites = st.favorites

    val shown = remember(tab, apps, favorites, query, searching) {
        val base = when {
            searching ->
                if (query.isBlank()) apps
                else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
            tab == 1 -> apps.filter { it.pkg in favorites }
            tab == 2 -> apps.filter { it.isGame }
            tab == 3 -> apps.filter { !it.isGame }
            else -> apps
        }
        base.sortedByDescending { it.pkg in favorites }
    }

    var selected by remember { mutableIntStateOf(0) }
    val safeSel = if (shown.isEmpty()) 0 else selected.coerceIn(0, shown.lastIndex)
    val listState = rememberLazyListState()
    val tabScroll = rememberScrollState()
    var time by remember { mutableStateOf(fmt("HH:mm")) }
    val battery = rememberBattery()
    val homeIn = remember { Animatable(0f) }
    val rowAnim = remember { Animatable(1f) }

    LaunchedEffect(stage) {
        if (stage == 2) homeIn.animateTo(1f, tween(900, easing = FastOutSlowInEasing))
    }
    LaunchedEffect(Unit) { while (true) { time = fmt("HH:mm"); delay(15_000) } }
    LaunchedEffect(tab, searching) {
        rowAnim.snapTo(0f)
        rowAnim.animateTo(1f, tween(380, easing = FastOutSlowInEasing))
    }
    LaunchedEffect(tab, searching, query) {
        selected = 0
        if (shown.isNotEmpty()) listState.scrollToItem(0)
    }
    LaunchedEffect(safeSel) {
        if (shown.isNotEmpty()) listState.animateScrollToItem(safeSel)
    }
    BackHandler {
        when {
            exitOpen -> exitOpen = false
            settingsOpen -> settingsOpen = false
            searching -> { hideKeyboard(view); searching = false; query = "" }
            else -> { /* launcher: stay home */ }
        }
    }

    val photo = st.bgImage

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        // ---- Background ----
        if (st.bgMode == 2 && photo != null) {
            Image(
                bitmap = photo, contentDescription = null,
                modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
            )
            Box(Modifier.fillMaxSize().background(Color(0x99000000)))
        } else {
            Box(
                Modifier.fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color(0xFF0B0B0C), Color.Black)))
            )
            if (st.bgMode == 0) GamingBackground() else RainBackground()
            Box(
                Modifier.fillMaxSize().background(
                    Brush.radialGradient(
                        colors = listOf(Gold.copy(alpha = 0.10f), Color.Transparent),
                        center = Offset(300f, 0f), radius = 1300f
                    )
                )
            )
        }

        // ---- Content ----
        Column(Modifier.fillMaxSize().padding(horizontal = 36.dp, vertical = 18.dp)) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .graphicsLayer {
                        alpha = homeIn.value
                        translationY = -(1f - homeIn.value) * 50f
                    },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("deckhome", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(16.dp))
                Box(Modifier.weight(1f)) {
                    if (searching) {
                        SearchField(onQuery = { query = it }, onDone = { hideKeyboard(view) })
                    } else {
                        Row(Modifier.horizontalScroll(tabScroll)) {
                            tabs.forEachIndexed { i, name ->
                                TabItem(name, i == tab) {
                                    if (tab != i) { tab = i; act.sfx(SFX_CLICK) }
                                }
                                Spacer(Modifier.width(4.dp))
                            }
                        }
                    }
                }
                Spacer(Modifier.width(10.dp))
                Pill(if (searching) "CLOSE" else "SEARCH", searching) {
                    act.sfx(SFX_CLICK)
                    if (searching) { hideKeyboard(view); searching = false; query = "" }
                    else searching = true
                }
                Spacer(Modifier.width(6.dp))
                GearIcon(settingsOpen) { act.sfx(SFX_CLICK); settingsOpen = true }
                PowerIcon { act.sfx(SFX_CLICK); exitOpen = true }
                Spacer(Modifier.width(8.dp))
                if (battery >= 0) {
                    Text("$battery%", color = TextDim, fontSize = 12.sp)
                    Spacer(Modifier.width(10.dp))
                }
                Text(time, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }

            Spacer(Modifier.weight(1f))

            val title = shown.getOrNull(safeSel)?.label
                ?: if (tab == 1 && !searching) "No favorites yet" else "No apps found"
            Row(
                Modifier
                    .fillMaxWidth()
                    .graphicsLayer {
                        alpha = homeIn.value
                        translationY = (1f - homeIn.value) * 40f
                    },
                verticalAlignment = Alignment.Bottom
            ) {
                Column(Modifier.weight(1f)) {
                    Crossfade(targetState = title, animationSpec = tween(220), label = "title") { t ->
                        Text(
                            t, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(start = 12.dp)
                        )
                    }
                    Text(
                        (if (searching) "SEARCH" else tabs[tab]) + "  \u2022  ${shown.size}",
                        color = Gold, fontSize = 12.sp, letterSpacing = 2.sp,
                        modifier = Modifier.padding(start = 12.dp, top = 2.dp, bottom = 6.dp)
                    )
                }
                EnjoyBadge(st.avatar)
            }

            LazyRow(
                state = listState,
                modifier = Modifier.graphicsLayer {
                    alpha = rowAnim.value
                    translationX = (1f - rowAnim.value) * 80f
                },
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                itemsIndexed(shown, key = { _, a -> a.pkg }) { i, app ->
                    AppCard(
                        app = app,
                        index = i,
                        visible = stage == 2,
                        isSelected = i == safeSel,
                        isFav = app.pkg in favorites,
                        onFocus = { if (selected != i) { selected = i; act.sfx(SFX_MOVE) } },
                        onClick = {
                            selected = i
                            act.sfx(SFX_OPEN)
                            ctx.packageManager.getLaunchIntentForPackage(app.pkg)
                                ?.let { ctx.startActivity(it) }
                        },
                        onLongClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            val wasFav = app.pkg in favorites
                            act.toggleFav(app.pkg)
                            act.sfx(if (wasFav) SFX_CLICK else SFX_POP)
                        }
                    )
                }
            }

            Spacer(Modifier.weight(1f))

            Text(
                "Tap  Open      Hold  Star      D-pad  Navigate",
                color = TextDim, fontSize = 12.sp,
                modifier = Modifier
                    .padding(start = 12.dp)
                    .graphicsLayer { alpha = homeIn.value }
            )
        }

        // ---- Settings ----
        AnimatedVisibility(
            visible = settingsOpen,
            enter = fadeIn(tween(220)) + scaleIn(tween(220), initialScale = 0.92f),
            exit = fadeOut(tween(150))
        ) {
            SettingsPanel(st, act) { act.sfx(SFX_CLICK); settingsOpen = false }
        }

        // ---- Exit dialog ----
        AnimatedVisibility(
            visible = exitOpen,
            enter = fadeIn(tween(200)) + scaleIn(tween(200), initialScale = 0.9f),
            exit = fadeOut(tween(150))
        ) {
            ExitDialog(
                onExit = { act.sfx(SFX_CLICK); act.exitApp() },
                onStay = { act.sfx(SFX_CLICK); exitOpen = false }
            )
        }

        // ---- Intro, then welcome ----
        if (stage == 0) {
            Intro(onRollEnd = { act.sfx(SFX_OPEN) }, onFinished = { stage = 1 })
        }
        if (stage == 1) {
            Welcome(onFinished = { stage = 2 })
        }
    }
}

// ------------------------------------------------------------------ Intro + Welcome

@Composable
fun Intro(onRollEnd: () -> Unit, onFinished: () -> Unit) {
    val roll = remember { Animatable(0f) }
    val ring = remember { Animatable(0f) }
    val underline = remember { Animatable(0f) }
    val fade = remember { Animatable(1f) }
    var typed by remember { mutableStateOf("") }
    val name = "deckhome"

    LaunchedEffect(Unit) {
        delay(350)
        roll.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessLow))
        onRollEnd()
        launch { ring.animateTo(1f, tween(1000, easing = LinearOutSlowInEasing)) }
        delay(150)
        for (i in 1..name.length) { typed = name.take(i); delay(95) }
        underline.animateTo(1f, tween(500, easing = FastOutSlowInEasing))
        delay(900)
        fade.animateTo(0f, tween(600))
        onFinished()
    }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = fade.value }
            .background(Color.Black)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                onFinished()
            },
        contentAlignment = Alignment.Center
    ) {
        val w = constraints.maxWidth.toFloat()
        GamingBackground()
        Canvas(Modifier.fillMaxSize()) {
            val glow = 0.30f * roll.value.coerceIn(0f, 1f)
            val rad = size.minDimension * 0.6f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Gold.copy(alpha = glow), Color.Transparent),
                    center = center, radius = rad
                ),
                radius = rad, center = center
            )
            if (ring.value > 0f && ring.value < 1f) {
                drawCircle(
                    color = Gold.copy(alpha = (1f - ring.value) * 0.8f),
                    radius = ring.value * size.maxDimension * 0.5f,
                    center = center,
                    style = Stroke(width = 3.dp.toPx())
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(contentAlignment = Alignment.Center) {
                for (g in 3 downTo 1) {
                    Text(
                        "M", color = Gold, fontSize = 100.sp, fontWeight = FontWeight.Black,
                        modifier = Modifier.graphicsLayer {
                            val left = (1f - roll.value).coerceAtLeast(0f)
                            translationX = -left * w * 0.6f - g * left * 46f
                            rotationZ = -left * 900f - g * left * 30f
                            alpha = min(1f, roll.value * 4f) * (0.40f - g * 0.09f) *
                                min(1f, left * 4f)
                        }
                    )
                }
                Text(
                    "M", color = Gold, fontSize = 100.sp, fontWeight = FontWeight.Black,
                    modifier = Modifier.graphicsLayer {
                        val left = 1f - roll.value
                        translationX = -left * w * 0.6f
                        rotationZ = -left * 900f
                        alpha = min(1f, roll.value * 4f)
                    }
                )
            }
            Text(
                typed, color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold,
                letterSpacing = 6.sp, maxLines = 1,
                modifier = Modifier.height(36.dp)
            )
            Box(Modifier.height(2.dp).width((150f * underline.value).dp).background(Gold))
        }
    }
}

@Composable
fun Welcome(onFinished: () -> Unit) {
    val appear = remember { Animatable(0f) }
    val sub = remember { Animatable(0f) }
    val line = remember { Animatable(0f) }
    val fade = remember { Animatable(1f) }
    val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
    val greeting = when {
        hour < 5 -> "Good night"
        hour < 12 -> "Good morning"
        hour < 18 -> "Good afternoon"
        else -> "Good evening"
    }

    LaunchedEffect(Unit) {
        launch { appear.animateTo(1f, tween(1000, easing = FastOutSlowInEasing)) }
        delay(500)
        launch { line.animateTo(1f, tween(700, easing = FastOutSlowInEasing)) }
        delay(300)
        sub.animateTo(1f, tween(600))
        delay(1100)
        fade.animateTo(0f, tween(600))
        onFinished()
    }

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = fade.value }
            .background(Color.Black)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                onFinished()
            },
        contentAlignment = Alignment.Center
    ) {
        GamingBackground()
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "WELCOME", color = Gold, fontSize = 38.sp, fontWeight = FontWeight.Bold,
                letterSpacing = (24f - 18f * appear.value).sp,
                modifier = Modifier.graphicsLayer {
                    alpha = appear.value
                    scaleX = 0.9f + 0.1f * appear.value
                    scaleY = 0.9f + 0.1f * appear.value
                }
            )
            Box(
                Modifier.padding(top = 10.dp).height(2.dp)
                    .width((160f * line.value).dp).background(Gold)
            )
            Text(
                "$greeting  \u2022  enjoy your apps",
                color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp, letterSpacing = 2.sp,
                modifier = Modifier
                    .padding(top = 12.dp)
                    .graphicsLayer {
                        alpha = sub.value
                        translationY = (1f - sub.value) * 16f
                    }
            )
        }
    }
}

// ------------------------------------------------------------------ Backgrounds

private data class Particle(
    val type: Int, val x0: Float, val y0: Float, val speed: Int, val dir: Int,
    val size: Float, val rot0: Float, val rotSpeed: Int,
    val amp: Float, val ph: Float, val m: Int, val alpha: Float
)

@Composable
fun GamingBackground() {
    val particles = remember {
        val r = kotlin.random.Random(11)
        List(26) {
            Particle(
                type = r.nextInt(7), x0 = r.nextFloat(), y0 = r.nextFloat(),
                speed = 1 + r.nextInt(2), dir = if (r.nextBoolean()) 1 else -1,
                size = 8f + r.nextFloat() * 14f, rot0 = r.nextFloat() * 360f,
                rotSpeed = r.nextInt(5) - 2, amp = 0.02f + r.nextFloat() * 0.05f,
                ph = r.nextFloat(), m = 1 + r.nextInt(3), alpha = 0.10f + r.nextFloat() * 0.18f
            )
        }
    }
    val transition = rememberInfiniteTransition(label = "bg")
    val t by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(90_000, easing = LinearEasing)),
        label = "t"
    )
    Canvas(Modifier.fillMaxSize()) {
        val tt = t
        val d = density
        val stroke = Stroke(width = 1.6f * d, cap = StrokeCap.Round, join = StrokeJoin.Round)
        particles.forEach { p ->
            val px = ((((p.x0 + p.dir * p.speed * tt) % 1f) + 1f) % 1f) * size.width
            val py = (p.y0 + p.amp * sin(2.0 * PI * (p.m * tt + p.ph)).toFloat()) * size.height
            val s = p.size * d
            val h = s / 2f
            val c = Gold.copy(alpha = p.alpha)
            rotate(p.rot0 + 360f * p.rotSpeed * tt, Offset(px, py)) {
                when (p.type) {
                    0 -> drawCircle(c, h, Offset(px, py), style = stroke)
                    1 -> drawRect(c, Offset(px - h, py - h), Size(s, s), style = stroke)
                    2 -> {
                        val path = Path().apply {
                            moveTo(px, py - h); lineTo(px + h, py + h * 0.8f)
                            lineTo(px - h, py + h * 0.8f); close()
                        }
                        drawPath(path, c, style = stroke)
                    }
                    3 -> {
                        drawLine(c, Offset(px - h, py - h), Offset(px + h, py + h), stroke.width, StrokeCap.Round)
                        drawLine(c, Offset(px - h, py + h), Offset(px + h, py - h), stroke.width, StrokeCap.Round)
                    }
                    4 -> {
                        drawLine(c, Offset(px - h, py), Offset(px + h, py), stroke.width * 1.6f, StrokeCap.Round)
                        drawLine(c, Offset(px, py - h), Offset(px, py + h), stroke.width * 1.6f, StrokeCap.Round)
                    }
                    5 -> {
                        val path = Path().apply {
                            moveTo(px, py - h); lineTo(px + h, py)
                            lineTo(px, py + h); lineTo(px - h, py); close()
                        }
                        drawPath(path, c, style = stroke)
                    }
                    else -> drawCircle(c, s * 0.14f, Offset(px, py))
                }
            }
        }
    }
}

private data class Drop(
    val x: Float, val y0: Float, val speed: Int, val len: Float, val alpha: Float
)

@Composable
fun RainBackground() {
    val drops = remember {
        val r = kotlin.random.Random(5)
        List(70) {
            Drop(
                x = r.nextFloat(), y0 = r.nextFloat(), speed = 2 + r.nextInt(3),
                len = 14f + r.nextFloat() * 18f, alpha = 0.10f + r.nextFloat() * 0.22f
            )
        }
    }
    val transition = rememberInfiniteTransition(label = "rain")
    val t by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(20_000, easing = LinearEasing)),
        label = "rt"
    )
    Canvas(Modifier.fillMaxSize()) {
        val tt = t
        val d = density
        drops.forEach { p ->
            val y = (((p.y0 + p.speed * tt) % 1f) + 1f) % 1f
            val len = p.len * d
            val px = p.x * size.width
            val py = y * (size.height + len) - len
            drawLine(
                Gold.copy(alpha = p.alpha), Offset(px, py), Offset(px, py + len),
                1.4f * d, StrokeCap.Round
            )
        }
    }
}

// ------------------------------------------------------------------ Small UI pieces

@Composable
fun SearchField(onQuery: (String) -> Unit, onDone: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .clip(shape)
            .border(1.dp, Gold, shape)
            .background(Gold.copy(alpha = 0.12f))
            .padding(horizontal = 12.dp)
    ) {
        AndroidView(
            modifier = Modifier.width(230.dp).height(38.dp),
            factory = { c ->
                EditText(c).apply {
                    hint = "Search apps..."
                    setHintTextColor(0x99FFFFFF.toInt())
                    setTextColor(0xFFFFFFFF.toInt())
                    textSize = 15f
                    setSingleLine(true)
                    background = null
                    inputType = InputType.TYPE_CLASS_TEXT
                    imeOptions = EditorInfo.IME_ACTION_SEARCH or EditorInfo.IME_FLAG_NO_EXTRACT_UI
                    addTextChangedListener(object : TextWatcher {
                        override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                        override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                        override fun afterTextChanged(s: Editable?) { onQuery(s?.toString().orEmpty()) }
                    })
                    setOnEditorActionListener { _, _, _ -> onDone(); true }
                    post {
                        requestFocus()
                        (c.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                            .showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
                    }
                }
            }
        )
    }
}

@Composable
fun Pill(text: String, filled: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Text(
        text,
        color = if (filled) Ink else Gold,
        fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, maxLines = 1,
        modifier = Modifier
            .clip(shape)
            .background(if (filled) Gold else Color.Transparent)
            .border(1.dp, Gold, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 5.dp)
    )
}

@Composable
fun BigButton(text: String, bg: Color, fg: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Text(
        text, color = fg, fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp,
        textAlign = TextAlign.Center, maxLines = 1,
        modifier = Modifier
            .width(240.dp)
            .clip(shape)
            .background(bg)
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp)
    )
}

@Composable
fun TabItem(name: String, active: Boolean, onClick: () -> Unit) {
    val color by animateColorAsState(if (active) Gold else TextDim, label = "tabColor")
    val barWidth by animateDpAsState(if (active) 24.dp else 0.dp, label = "tabBar")
    Column(
        Modifier
            .clip(RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(name, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, maxLines = 1)
        Box(Modifier.padding(top = 3.dp).height(2.dp).width(barWidth).background(Gold))
    }
}

@Composable
fun GearIcon(open: Boolean, onClick: () -> Unit) {
    val rot by animateFloatAsState(if (open) 90f else 0f, tween(450), label = "gear")
    Canvas(
        Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .padding(8.dp)
            .graphicsLayer { rotationZ = rot }
    ) {
        val s = size.minDimension
        val c = center
        val sw = s * 0.11f
        drawCircle(Gold, s * 0.24f, c, style = Stroke(width = sw))
        drawCircle(Gold, s * 0.07f, c)
        for (i in 0 until 8) {
            val a = i * PI / 4
            val x1 = c.x + (cos(a) * s * 0.34f).toFloat()
            val y1 = c.y + (sin(a) * s * 0.34f).toFloat()
            val x2 = c.x + (cos(a) * s * 0.48f).toFloat()
            val y2 = c.y + (sin(a) * s * 0.48f).toFloat()
            drawLine(Gold, Offset(x1, y1), Offset(x2, y2), s * 0.15f, StrokeCap.Round)
        }
    }
}

@Composable
fun PowerIcon(onClick: () -> Unit) {
    val red = Color(0xFFFF5A5A)
    Canvas(
        Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .padding(9.dp)
    ) {
        val s = size.minDimension
        val sw = s * 0.12f
        drawArc(
            color = red, startAngle = -60f, sweepAngle = 300f, useCenter = false,
            topLeft = Offset(sw / 2f, s * 0.14f + sw / 2f),
            size = Size(s - sw, s * 0.86f - sw),
            style = Stroke(width = sw, cap = StrokeCap.Round)
        )
        drawLine(red, Offset(s / 2f, sw / 2f), Offset(s / 2f, s * 0.5f), sw, StrokeCap.Round)
    }
}

@Composable
fun StarBadge(modifier: Modifier = Modifier) {
    Canvas(modifier.size(20.dp)) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val outer = size.minDimension / 2f
        val inner = outer * 0.42f
        val path = Path()
        for (i in 0 until 10) {
            val r = if (i % 2 == 0) outer else inner
            val a = -PI / 2 + i * PI / 5
            val x = cx + (r * cos(a)).toFloat()
            val y = cy + (r * sin(a)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        drawPath(path, Gold)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppCard(
    app: AppItem,
    index: Int,
    visible: Boolean,
    isSelected: Boolean,
    isFav: Boolean,
    onFocus: () -> Unit,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val enter = remember { Animatable(0f) }
    LaunchedEffect(visible) {
        if (visible) {
            delay((index % 7) * 70L)
            enter.animateTo(1f, tween(500, easing = FastOutSlowInEasing))
        }
    }
    val target = if (pressed) 0.94f else if (isSelected) 1.12f else 1f
    val scale by animateFloatAsState(
        target,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "cardScale"
    )
    val shape = RoundedCornerShape(14.dp)
    Box(
        Modifier
            .graphicsLayer {
                val k = scale * (0.85f + 0.15f * enter.value)
                scaleX = k
                scaleY = k
                alpha = enter.value
                translationY = (1f - enter.value) * 50f
            }
            .width(130.dp)
            .height(175.dp)
            .shadow(if (isSelected) 18.dp else 0.dp, shape, ambientColor = Gold, spotColor = Gold)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(app.tint.copy(alpha = 0.32f), Panel)))
            .border(
                width = if (isSelected) 3.dp else 1.dp,
                color = if (isSelected) Gold else Color(0x26FFFFFF),
                shape = shape
            )
            .onFocusChanged { if (it.isFocused) onFocus() }
            .combinedClickable(
                interactionSource = interaction,
                indication = null,
                onClick = onClick,
                onLongClick = onLongClick
            )
    ) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Image(app.icon, app.label, Modifier.size(80.dp))
            Text(
                app.label, color = Color.White, fontSize = 13.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
            )
        }
        if (isFav) StarBadge(Modifier.align(Alignment.TopEnd).padding(8.dp))
    }
}

// ------------------------------------------------------------------ Enjoy sign + character heads

@Composable
fun EnjoyBadge(avatar: Int) {
    val transition = rememberInfiniteTransition(label = "badge")
    val bob by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse
        ),
        label = "bob"
    )
    val shape = RoundedCornerShape(8.dp)
    Row(verticalAlignment = Alignment.Bottom) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer { rotationZ = -3f + 6f * bob }
        ) {
            Row(
                Modifier.width(74.dp).padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box(Modifier.width(2.dp).height(9.dp).background(Gold.copy(alpha = 0.7f)))
                Box(Modifier.width(2.dp).height(9.dp).background(Gold.copy(alpha = 0.7f)))
            }
            Text(
                "enjoy", color = Gold, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp, textAlign = TextAlign.Center, maxLines = 1,
                modifier = Modifier
                    .width(74.dp)
                    .clip(shape)
                    .background(Gold.copy(alpha = 0.12f))
                    .border(1.5.dp, Gold, shape)
                    .padding(vertical = 5.dp)
            )
        }
        if (avatar in 0..4) {
            Spacer(Modifier.width(8.dp))
            Canvas(
                Modifier
                    .size(54.dp)
                    .graphicsLayer { translationY = (0.5f - bob) * 8f }
            ) { drawAvatar(avatar, Gold) }
        }
    }
}

// Simple original line-art heads (inspired by the five characters, not copies).
private fun DrawScope.drawAvatar(kind: Int, c: Color) {
    val s = size.minDimension
    val stroke = Stroke(width = s * 0.05f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    val lw = s * 0.05f
    fun o(x: Float, y: Float) = Offset(x * s, y * s)
    fun sz(w: Float, h: Float) = Size(w * s, h * s)
    when (kind) {
        0 -> { // smiling girl with ponytail
            drawCircle(c, s * 0.27f, o(0.5f, 0.58f), style = stroke)
            drawArc(
                color = c, startAngle = 180f, sweepAngle = 180f, useCenter = false,
                topLeft = o(0.19f, 0.20f), size = sz(0.62f, 0.62f), style = stroke
            )
            val tail = Path().apply {
                moveTo(0.78f * s, 0.44f * s)
                cubicTo(0.98f * s, 0.40f * s, 0.98f * s, 0.70f * s, 0.80f * s, 0.78f * s)
            }
            drawPath(tail, c, style = stroke)
            drawLine(c, o(0.34f, 0.33f), o(0.46f, 0.42f), lw, StrokeCap.Round)
            drawLine(c, o(0.50f, 0.31f), o(0.58f, 0.40f), lw, StrokeCap.Round)
            drawCircle(c, s * 0.028f, o(0.41f, 0.60f))
            drawCircle(c, s * 0.028f, o(0.59f, 0.60f))
            drawArc(
                color = c, startAngle = 25f, sweepAngle = 130f, useCenter = false,
                topLeft = o(0.38f, 0.60f), size = sz(0.24f, 0.17f), style = stroke
            )
        }
        1 -> { // little horned knight
            drawOval(c, o(0.24f, 0.30f), sz(0.52f, 0.52f), style = stroke)
            val left = Path().apply {
                moveTo(0.36f * s, 0.34f * s)
                cubicTo(0.30f * s, 0.20f * s, 0.22f * s, 0.14f * s, 0.18f * s, 0.04f * s)
            }
            val right = Path().apply {
                moveTo(0.64f * s, 0.34f * s)
                cubicTo(0.70f * s, 0.20f * s, 0.78f * s, 0.14f * s, 0.82f * s, 0.04f * s)
            }
            drawPath(left, c, style = stroke)
            drawPath(right, c, style = stroke)
            drawOval(c, o(0.34f, 0.50f), sz(0.10f, 0.15f))
            drawOval(c, o(0.56f, 0.50f), sz(0.10f, 0.15f))
        }
        2 -> { // space soldier helmet
            drawRoundRect(
                color = c, topLeft = o(0.20f, 0.14f), size = sz(0.60f, 0.72f),
                cornerRadius = CornerRadius(0.28f * s, 0.28f * s), style = stroke
            )
            val visor = Path().apply {
                moveTo(0.28f * s, 0.40f * s); lineTo(0.72f * s, 0.40f * s)
                lineTo(0.66f * s, 0.60f * s); lineTo(0.34f * s, 0.60f * s); close()
            }
            drawPath(visor, c.copy(alpha = 0.35f))
            drawPath(visor, c, style = stroke)
            drawLine(c, o(0.50f, 0.14f), o(0.50f, 0.30f), lw, StrokeCap.Round)
            drawLine(c, o(0.40f, 0.72f), o(0.60f, 0.72f), lw, StrokeCap.Round)
            drawLine(c, o(0.40f, 0.79f), o(0.60f, 0.79f), lw, StrokeCap.Round)
        }
        3 -> { // smiley blob
            drawOval(c, o(0.20f, 0.24f), sz(0.60f, 0.58f), style = stroke)
            drawLine(c, o(0.42f, 0.24f), o(0.40f, 0.12f), lw, StrokeCap.Round)
            drawLine(c, o(0.50f, 0.24f), o(0.50f, 0.10f), lw, StrokeCap.Round)
            drawLine(c, o(0.58f, 0.24f), o(0.60f, 0.12f), lw, StrokeCap.Round)
            drawOval(c, o(0.36f, 0.44f), sz(0.07f, 0.12f))
            drawOval(c, o(0.57f, 0.44f), sz(0.07f, 0.12f))
            drawArc(
                color = c, startAngle = 15f, sweepAngle = 150f, useCenter = false,
                topLeft = o(0.34f, 0.50f), size = sz(0.32f, 0.22f), style = stroke
            )
        }
        else -> { // happy cap + mustache
            drawCircle(c, s * 0.26f, o(0.5f, 0.60f), style = stroke)
            drawArc(
                color = c, startAngle = 180f, sweepAngle = 180f, useCenter = false,
                topLeft = o(0.20f, 0.12f), size = sz(0.60f, 0.50f), style = stroke
            )
            drawLine(c, o(0.14f, 0.37f), o(0.86f, 0.37f), lw, StrokeCap.Round)
            drawCircle(c, s * 0.055f, o(0.5f, 0.24f), style = stroke)
            drawOval(c, o(0.40f, 0.48f), sz(0.06f, 0.10f))
            drawOval(c, o(0.54f, 0.48f), sz(0.06f, 0.10f))
            drawCircle(c, s * 0.07f, o(0.5f, 0.60f), style = stroke)
            drawArc(
                color = c, startAngle = 0f, sweepAngle = 180f, useCenter = false,
                topLeft = o(0.28f, 0.62f), size = sz(0.22f, 0.12f), style = stroke
            )
            drawArc(
                color = c, startAngle = 0f, sweepAngle = 180f, useCenter = false,
                topLeft = o(0.50f, 0.62f), size = sz(0.22f, 0.12f), style = stroke
            )
            drawArc(
                color = c, startAngle = 20f, sweepAngle = 140f, useCenter = false,
                topLeft = o(0.40f, 0.72f), size = sz(0.20f, 0.12f), style = stroke
            )
        }
    }
}

// ------------------------------------------------------------------ Dialogs & settings

@Composable
fun ExitDialog(onExit: () -> Unit, onStay: () -> Unit) {
    val scrimSrc = remember { MutableInteractionSource() }
    val panelSrc = remember { MutableInteractionSource() }
    val shape = RoundedCornerShape(18.dp)
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .clickable(interactionSource = scrimSrc, indication = null, onClick = onStay),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .clip(shape)
                .background(Panel)
                .border(1.dp, Color(0x33FFFFFF), shape)
                .clickable(interactionSource = panelSrc, indication = null) { }
                .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            BigButton("DO YOU WANT EXIT", Color(0xFFE53935), Color.White, onExit)
            Spacer(Modifier.height(12.dp))
            BigButton("STAY", Color.White, Color.Black, onStay)
        }
    }
}

@Composable
fun NavItem(text: String, active: Boolean, onClick: () -> Unit) {
    val color by animateColorAsState(if (active) Gold else TextDim, label = "nav")
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 9.dp, horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(3.dp).height(14.dp).background(if (active) Gold else Color.Transparent))
        Spacer(Modifier.width(8.dp))
        Text(text, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, maxLines = 1)
    }
}

@Composable
fun OptionRow(text: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 7.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(10.dp)
                .clip(RoundedCornerShape(50))
                .border(1.5.dp, Gold, RoundedCornerShape(50))
                .background(if (selected) Gold else Color.Transparent)
        )
        Spacer(Modifier.width(10.dp))
        Text(
            text, color = if (selected) Color.White else TextDim, fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(text, color = TextDim, fontSize = 11.sp, letterSpacing = 2.sp)
    Spacer(Modifier.height(8.dp))
}

@Composable
fun SettingsPanel(st: HomeState, act: HomeActions, onClose: () -> Unit) {
    val scrimSrc = remember { MutableInteractionSource() }
    val panelSrc = remember { MutableInteractionSource() }
    val shape = RoundedCornerShape(18.dp)
    var section by remember { mutableIntStateOf(0) }
    val names = listOf("MUSIC", "BACKGROUND", "THEME", "CHARACTER")

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .clickable(interactionSource = scrimSrc, indication = null, onClick = onClose),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .fillMaxWidth(0.9f)
                .widthIn(max = 640.dp)
                .fillMaxHeight(0.88f)
                .heightIn(max = 310.dp)
                .clip(shape)
                .background(Panel)
                .border(1.dp, Gold, shape)
                .clickable(interactionSource = panelSrc, indication = null) { }
                .padding(18.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("SETTINGS", color = Gold, fontSize = 16.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Spacer(Modifier.weight(1f))
                Pill("CLOSE", false, onClose)
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.weight(1f).fillMaxWidth()) {
                Column(Modifier.width(118.dp).fillMaxHeight()) {
                    names.forEachIndexed { i, n ->
                        NavItem(n, i == section) { act.sfx(SFX_CLICK); section = i }
                    }
                }
                Box(Modifier.width(1.dp).fillMaxHeight().background(Color(0x33FFFFFF)))
                Spacer(Modifier.width(14.dp))
                Box(Modifier.weight(1f).fillMaxHeight()) {
                    Crossfade(targetState = section, animationSpec = tween(220), label = "section") { s ->
                        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                            when (s) {
                                0 -> MusicSection(st, act)
                                1 -> BackgroundSection(st, act)
                                2 -> ThemeSection(st, act)
                                else -> CharacterSection(st, act)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MusicSection(st: HomeState, act: HomeActions) {
    SectionLabel("BACKGROUND MUSIC")
    Pill(if (st.musicOn) "MUSIC ON" else "MUSIC OFF", st.musicOn) {
        act.sfx(SFX_CLICK); act.toggleMusic()
    }
    Spacer(Modifier.height(14.dp))
    SectionLabel("TRACK")
    val names = listOf("Drift", "Dawn", "Midnight", "Glow")
    names.forEachIndexed { i, n ->
        OptionRow(n, st.track == i) { act.sfx(SFX_CLICK); act.chooseTrack(i) }
    }
    OptionRow(
        st.customName?.let { "Custom: $it" } ?: "Custom (none yet)",
        st.track == 4
    ) {
        act.sfx(SFX_CLICK)
        if (st.customName != null) act.chooseTrack(4) else act.pickMusic()
    }
    Spacer(Modifier.height(10.dp))
    Pill("CHOOSE MUSIC FILE", false) { act.sfx(SFX_CLICK); act.pickMusic() }
}

@Composable
fun BackgroundSection(st: HomeState, act: HomeActions) {
    SectionLabel("BACKGROUND STYLE")
    Row {
        Pill("GAMING", st.bgMode == 0) { act.sfx(SFX_CLICK); act.chooseBg(0) }
        Spacer(Modifier.width(8.dp))
        Pill("BLACK RAIN", st.bgMode == 1) { act.sfx(SFX_CLICK); act.chooseBg(1) }
        Spacer(Modifier.width(8.dp))
        Pill("PHOTO", st.bgMode == 2 && st.bgImage != null) {
            act.sfx(SFX_CLICK)
            if (st.bgImage != null) act.chooseBg(2) else act.pickPhoto()
        }
    }
    Spacer(Modifier.height(14.dp))
    Pill("CHOOSE PHOTO FROM GALLERY", false) { act.sfx(SFX_CLICK); act.pickPhoto() }
    Spacer(Modifier.height(10.dp))
    Text(
        "Gaming: floating symbols.  Black rain: calm falling rain.  Photo: your own image.",
        color = TextDim, fontSize = 11.sp
    )
}

@Composable
fun ThemeSection(st: HomeState, act: HomeActions) {
    SectionLabel("COLOR WHEEL")
    Row(verticalAlignment = Alignment.CenterVertically) {
        ColorWheel(
            selected = st.accent,
            onSelect = { act.sfx(SFX_CLICK); act.chooseAccent(it) },
            modifier = Modifier.size(132.dp)
        )
        Spacer(Modifier.width(16.dp))
        Column {
            Text(
                ACCENT_NAMES[st.accent.coerceIn(0, ACCENT_NAMES.lastIndex)],
                color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp
            )
            Spacer(Modifier.height(4.dp))
            Text("Tap a slice to recolor the whole app", color = TextDim, fontSize = 11.sp)
        }
    }
}

@Composable
fun ColorWheel(selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    Canvas(
        modifier.pointerInput(Unit) {
            detectTapGestures { p ->
                val cx = size.width / 2f
                val cy = size.height / 2f
                val dx = p.x - cx
                val dy = p.y - cy
                val r = sqrt(dx * dx + dy * dy)
                val outer = size.width / 2f
                if (r >= outer * 0.30f && r <= outer) {
                    var deg = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat() + 90f
                    deg = ((deg % 360f) + 360f) % 360f
                    onSelect(min(6, (deg / (360f / 7f)).toInt()))
                }
            }
        }
    ) {
        val n = 7
        val seg = 360f / n
        val m = 4.dp.toPx()
        val ring = size.minDimension * 0.30f
        val arcTopLeft = Offset(m + ring / 2f, m + ring / 2f)
        val arcSize = Size(size.minDimension - 2f * m - ring, size.minDimension - 2f * m - ring)
        for (i in 0 until n) {
            val start = -90f + i * seg + 2.5f
            val sweep = seg - 5f
            if (i == selected) {
                drawArc(
                    color = Color.White, startAngle = start, sweepAngle = sweep, useCenter = false,
                    topLeft = arcTopLeft, size = arcSize,
                    style = Stroke(width = ring + 6.dp.toPx())
                )
            }
            drawArc(
                color = ACCENTS[i], startAngle = start, sweepAngle = sweep, useCenter = false,
                topLeft = arcTopLeft, size = arcSize, style = Stroke(width = ring)
            )
        }
        val innerR = (size.minDimension - 2f * m - ring) / 2f - ring / 2f - 3.dp.toPx()
        drawCircle(Color.Black, innerR, center)
        drawCircle(ACCENTS[selected.coerceIn(0, 6)], innerR * 0.45f, center)
    }
}

@Composable
fun CharacterSection(st: HomeState, act: HomeActions) {
    var expanded by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(10.dp)
    SectionLabel("CHARACTER NEXT TO THE SIGN")
    Row(verticalAlignment = Alignment.Top) {
        Column(Modifier.animateContentSize()) {
            Row(
                Modifier
                    .clip(shape)
                    .border(1.dp, Gold, shape)
                    .clickable { act.sfx(SFX_CLICK); expanded = !expanded }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    AVATAR_NAMES[st.avatar.coerceIn(0, AVATAR_NAMES.lastIndex)],
                    color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.width(10.dp))
                Canvas(Modifier.size(10.dp).graphicsLayer { rotationZ = if (expanded) 180f else 0f }) {
                    val path = Path().apply {
                        moveTo(0f, size.height * 0.25f)
                        lineTo(size.width, size.height * 0.25f)
                        lineTo(size.width / 2f, size.height * 0.85f)
                        close()
                    }
                    drawPath(path, Gold)
                }
            }
            if (expanded) {
                Spacer(Modifier.height(4.dp))
                AVATAR_NAMES.forEachIndexed { i, n ->
                    OptionRow(n, st.avatar == i) {
                        act.sfx(SFX_CLICK)
                        act.chooseAvatar(i)
                        expanded = false
                    }
                }
            }
        }
        if (st.avatar in 0..4) {
            Spacer(Modifier.width(16.dp))
            Canvas(Modifier.size(48.dp)) { drawAvatar(st.avatar, Gold) }
        }
    }
}
