package com.mzenix.deckhome

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.BatteryManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AppItem(
    val label: String,
    val pkg: String,
    val icon: ImageBitmap,
    val tint: Color,
    val isGame: Boolean
)

private val Gold = Color(0xFFFFC629)
private val Panel = Color(0xFF111112)
private val TextDim = Color(0xFF9A9A9A)
private val Ink = Color(0xFF050505)

private const val SFX_MOVE = 0
private const val SFX_CLICK = 1
private const val SFX_OPEN = 2

class MainActivity : ComponentActivity() {

    private var player: MediaPlayer? = null
    private var sounds: SoundPool? = null
    private var sMove = 0
    private var sClick = 0
    private var sOpen = 0
    private var musicOn by mutableStateOf(true)
    private val prefs by lazy { getSharedPreferences("deckhome", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        musicOn = prefs.getBoolean("music", true)
        initAudio()
        val apps = loadApps()
        setContent {
            DeckHome(
                apps = apps,
                musicOn = musicOn,
                onToggleMusic = { toggleMusic() },
                sfx = { sfx(it) }
            )
        }
    }

    override fun onStart() {
        super.onStart()
        if (musicOn) player?.start()
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release(); player = null
        sounds?.release(); sounds = null
    }

    private fun initAudio() {
        player = MediaPlayer.create(this, R.raw.ambient)?.apply {
            isLooping = true
            setVolume(0.35f, 0.35f)
        }
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        sounds = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build().also {
            sMove = it.load(this, R.raw.sfx_move, 1)
            sClick = it.load(this, R.raw.sfx_click, 1)
            sOpen = it.load(this, R.raw.sfx_open, 1)
        }
    }

    private fun toggleMusic() {
        musicOn = !musicOn
        prefs.edit().putBoolean("music", musicOn).apply()
        if (musicOn) player?.start() else player?.pause()
    }

    private fun sfx(kind: Int) {
        val id = when (kind) {
            SFX_MOVE -> sMove
            SFX_OPEN -> sOpen
            else -> sClick
        }
        sounds?.play(id, 0.8f, 0.8f, 1, 0, 1f)
    }

    @Suppress("DEPRECATION")
    private fun loadApps(): List<AppItem> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                val bmp = it.loadIcon(pm).toBitmap(192, 192)
                val px = Bitmap.createScaledBitmap(bmp, 1, 1, true).getPixel(0, 0)
                val ai = it.activityInfo.applicationInfo
                AppItem(
                    label = it.loadLabel(pm).toString(),
                    pkg = it.activityInfo.packageName,
                    icon = bmp.asImageBitmap(),
                    tint = Color(0xFF000000.toInt() or (px and 0xFFFFFF)),
                    isGame = ai.category == ApplicationInfo.CATEGORY_GAME ||
                        (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                )
            }
            .sortedBy { it.label.lowercase() }
    }
}

private fun fmt(pattern: String): String =
    SimpleDateFormat(pattern, Locale.getDefault()).format(Date())

@Composable
fun rememberBattery(): Int {
    val ctx = LocalContext.current
    var level by remember { mutableIntStateOf(-1) }
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                if (l >= 0 && s > 0) level = l * 100 / s
            }
        }
        val sticky = ContextCompat.registerReceiver(
            ctx, receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        sticky?.let { receiver.onReceive(ctx, it) }
        onDispose { ctx.unregisterReceiver(receiver) }
    }
    return level
}

@Composable
fun DeckHome(
    apps: List<AppItem>,
    musicOn: Boolean,
    onToggleMusic: () -> Unit,
    sfx: (Int) -> Unit
) {
    val ctx = LocalContext.current
    val tabs = listOf("ALL", "GAMES", "APPS")
    var tab by remember { mutableIntStateOf(0) }
    val shown = remember(tab, apps) {
        when (tab) {
            1 -> apps.filter { it.isGame }
            2 -> apps.filter { !it.isGame }
            else -> apps
        }
    }
    var selected by remember { mutableIntStateOf(0) }
    val safeSel = if (shown.isEmpty()) 0 else selected.coerceIn(0, shown.lastIndex)
    val listState = rememberLazyListState()
    var time by remember { mutableStateOf(fmt("HH:mm")) }
    val battery = rememberBattery()
    val intro = remember { Animatable(0f) }

    LaunchedEffect(Unit) { intro.animateTo(1f, tween(700)) }
    LaunchedEffect(Unit) { while (true) { time = fmt("HH:mm"); delay(15_000) } }
    LaunchedEffect(tab) {
        selected = 0
        if (shown.isNotEmpty()) listState.scrollToItem(0)
    }
    LaunchedEffect(safeSel) {
        if (shown.isNotEmpty()) listState.animateScrollToItem(safeSel)
    }
    BackHandler { /* launcher: stay home */ }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0B0B0C), Color.Black)))
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(Gold.copy(alpha = 0.12f), Color.Transparent),
                        center = Offset(300f, 0f),
                        radius = 1300f
                    )
                )
        )

        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 36.dp, vertical = 18.dp)
                .graphicsLayer {
                    alpha = intro.value
                    translationY = (1f - intro.value) * 60f
                }
        ) {
            // ---- Top bar ----
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("deckhome", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(26.dp))
                    tabs.forEachIndexed { i, name ->
                        TabItem(name, i == tab) {
                            if (tab != i) { tab = i; sfx(SFX_CLICK) }
                        }
                        Spacer(Modifier.width(10.dp))
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    MusicPill(musicOn) { sfx(SFX_CLICK); onToggleMusic() }
                    Spacer(Modifier.width(16.dp))
                    if (battery >= 0) {
                        Text("$battery%", color = TextDim, fontSize = 14.sp)
                        Spacer(Modifier.width(16.dp))
                    }
                    Text(time, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                }
            }

            Spacer(Modifier.weight(1f))

            // ---- Selected title ----
            Text(
                shown.getOrNull(safeSel)?.label ?: "No apps here",
                color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(start = 12.dp)
            )
            Text(
                "${tabs[tab]}  \u2022  ${shown.size}",
                color = Gold, fontSize = 12.sp, letterSpacing = 2.sp,
                modifier = Modifier.padding(start = 12.dp, top = 2.dp, bottom = 10.dp)
            )

            // ---- Cards ----
            LazyRow(
                state = listState,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                itemsIndexed(shown, key = { _, a -> a.pkg }) { i, app ->
                    AppCard(
                        app = app,
                        isSelected = i == safeSel,
                        onFocus = {
                            if (selected != i) { selected = i; sfx(SFX_MOVE) }
                        },
                        onClick = {
                            selected = i
                            sfx(SFX_OPEN)
                            ctx.packageManager.getLaunchIntentForPackage(app.pkg)
                                ?.let { ctx.startActivity(it) }
                        }
                    )
                }
            }

            Spacer(Modifier.weight(1f))

            Text(
                "A  Open      D-pad  Navigate",
                color = TextDim, fontSize = 12.sp,
                modifier = Modifier.padding(start = 12.dp)
            )
        }
    }
}

@Composable
fun TabItem(name: String, active: Boolean, onClick: () -> Unit) {
    val color by animateColorAsState(if (active) Gold else TextDim, label = "tabColor")
    val barWidth by animateDpAsState(if (active) 24.dp else 0.dp, label = "tabBar")
    Column(
        Modifier
            .clip(RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(name, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Box(Modifier.padding(top = 3.dp).height(2.dp).width(barWidth).background(Gold))
    }
}

@Composable
fun MusicPill(on: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Text(
        if (on) "MUSIC ON" else "MUSIC OFF",
        color = if (on) Ink else Gold,
        fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp,
        modifier = Modifier
            .clip(shape)
            .background(if (on) Gold else Color.Transparent)
            .border(1.dp, Gold, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 5.dp)
    )
}

@Composable
fun AppCard(app: AppItem, isSelected: Boolean, onFocus: () -> Unit, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val target = if (pressed) 0.94f else if (isSelected) 1.12f else 1f
    val scale by animateFloatAsState(
        target,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "cardScale"
    )
    val shape = RoundedCornerShape(14.dp)
    Column(
        Modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .shadow(if (isSelected) 18.dp else 0.dp, shape, ambientColor = Gold, spotColor = Gold)
            .width(130.dp)
            .height(175.dp)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(app.tint.copy(alpha = 0.32f), Panel)))
            .border(
                width = if (isSelected) 3.dp else 1.dp,
                color = if (isSelected) Gold else Color(0x26FFFFFF),
                shape = shape
            )
            .onFocusChanged { if (it.isFocused) onFocus() }
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Image(app.icon, app.label, Modifier.size(80.dp))
        Text(
            app.label, color = Color.White, fontSize = 13.sp,
            maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
        )
    }
}
