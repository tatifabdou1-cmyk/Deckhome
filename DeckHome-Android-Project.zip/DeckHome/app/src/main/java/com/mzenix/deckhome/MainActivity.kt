package com.mzenix.deckhome

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

data class AppItem(
    val label: String,
    val pkg: String,
    val icon: ImageBitmap,
    val tint: Color,
    val isGame: Boolean
)

private val Gold = Color(0xFFFFC629)
private val Panel = Color(0xFF111112)
private val TextDim = Color(0xFF9A9A9A)
private val Ink = Color(0xFF050505)

private const val SFX_MOVE = 0
private const val SFX_CLICK = 1
private const val SFX_OPEN = 2

class MainActivity : ComponentActivity() {

    private var player: MediaPlayer? = null
    private var sounds: SoundPool? = null
    private var sMove = 0
    private var sClick = 0
    private var sOpen = 0
    private var musicOn by mutableStateOf(true)
    private var favorites by mutableStateOf(setOf<String>())
    private var bgMode by mutableIntStateOf(0)
    private var bgImage by mutableStateOf<ImageBitmap?>(null)
    private val prefs by lazy { getSharedPreferences("deckhome", MODE_PRIVATE) }

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: Exception) { }
            val img = loadBg(uri)
            if (img != null) {
                bgImage = img
                prefs.edit().putString("bg_uri", uri.toString()).apply()
                setBgMode(2)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        musicOn = prefs.getBoolean("music", true)
        favorites = prefs.getStringSet("fav", emptySet())?.toSet() ?: emptySet()
        bgMode = prefs.getInt("bg_mode", 0)
        prefs.getString("bg_uri", null)?.let { bgImage = loadBg(Uri.parse(it)) }
        initAudio()
        val apps = loadApps()
        setContent {
            DeckHome(
                apps = apps,
                musicOn = musicOn,
                onToggleMusic = { toggleMusic() },
                sfx = { sfx(it) },
                favorites = favorites,
                onToggleFav = { toggleFavorite(it) },
                bgMode = bgMode,
                bgImage = bgImage,
                onBgMode = { setBgMode(it) },
                onPickPhoto = { picker.launch(arrayOf("image/*")) }
            )
        }
    }

    override fun onStart() {
        super.onStart()
        if (musicOn) player?.start()
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release(); player = null
        sounds?.release(); sounds = null
    }

    private fun initAudio() {
        player = MediaPlayer.create(this, R.raw.ambient)?.apply {
            isLooping = true
            setVolume(0.35f, 0.35f)
        }
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        sounds = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build().also {
            sMove = it.load(this, R.raw.sfx_move, 1)
            sClick = it.load(this, R.raw.sfx_click, 1)
            sOpen = it.load(this, R.raw.sfx_open, 1)
        }
    }

    private fun toggleMusic() {
        musicOn = !musicOn
        prefs.edit().putBoolean("music", musicOn).apply()
        if (musicOn) player?.start() else player?.pause()
    }

    private fun toggleFavorite(pkg: String) {
        favorites = if (pkg in favorites) favorites - pkg else favorites + pkg
        prefs.edit().putStringSet("fav", HashSet(favorites)).apply()
    }

    private fun setBgMode(mode: Int) {
        bgMode = mode
        prefs.edit().putInt("bg_mode", mode).apply()
    }

    private fun loadBg(uri: Uri): ImageBitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 2000 || bounds.outHeight / sample > 2000) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?.asImageBitmap()
    } catch (e: Exception) {
        null
    }

    private fun sfx(kind: Int) {
        val id = when (kind) {
            SFX_MOVE -> sMove
            SFX_OPEN -> sOpen
            else -> sClick
        }
        sounds?.play(id, 0.8f, 0.8f, 1, 0, 1f)
    }

    @Suppress("DEPRECATION")
    private fun loadApps(): List<AppItem> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                val bmp = it.loadIcon(pm).toBitmap(192, 192)
                val px = Bitmap.createScaledBitmap(bmp, 1, 1, true).getPixel(0, 0)
                val ai = it.activityInfo.applicationInfo
                AppItem(
                    label = it.loadLabel(pm).toString(),
                    pkg = it.activityInfo.packageName,
                    icon = bmp.asImageBitmap(),
                    tint = Color(0xFF000000.toInt() or (px and 0xFFFFFF)),
                    isGame = ai.category == ApplicationInfo.CATEGORY_GAME ||
                        (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                )
            }
            .sortedBy { it.label.lowercase() }
    }
}

private fun fmt(pattern: String): String =
    SimpleDateFormat(pattern, Locale.getDefault()).format(Date())

private fun hideKeyboard(v: View) {
    (v.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        .hideSoftInputFromWindow(v.windowToken, 0)
}

@Composable
fun rememberBattery(): Int {
    val ctx = LocalContext.current
    var level by remember { mutableIntStateOf(-1) }
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                if (l >= 0 && s > 0) level = l * 100 / s
            }
        }
        val sticky = ContextCompat.registerReceiver(
            ctx, receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        sticky?.let { receiver.onReceive(ctx, it) }
        onDispose { ctx.unregisterReceiver(receiver) }
    }
    return level
}

// ---------------------------------------------------------------- Home

@Composable
fun DeckHome(
    apps: List<AppItem>,
    musicOn: Boolean,
    onToggleMusic: () -> Unit,
    sfx: (Int) -> Unit,
    favorites: Set<String>,
    onToggleFav: (String) -> Unit,
    bgMode: Int,
    bgImage: ImageBitmap?,
    onBgMode: (Int) -> Unit,
    onPickPhoto: () -> Unit
) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val haptic = LocalHapticFeedback.current
    val tabs = listOf("ALL", "FAV", "GAMES", "APPS")
    var tab by remember { mutableIntStateOf(0) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var settingsOpen by remember { mutableStateOf(false) }
    var showIntro by remember { mutableStateOf(true) }

    val shown = remember(tab, apps, favorites, query, searching) {
        val base = when {
            searching ->
                if (query.isBlank()) apps
                else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
            tab == 1 -> apps.filter { it.pkg in favorites }
            tab == 2 -> apps.filter { it.isGame }
            tab == 3 -> apps.filter { !it.isGame }
            else -> apps
        }
        base.sortedByDescending { it.pkg in favorites }
    }

    var selected by remember { mutableIntStateOf(0) }
    val safeSel = if (shown.isEmpty()) 0 else selected.coerceIn(0, shown.lastIndex)
    val listState = rememberLazyListState()
    val tabScroll = rememberScrollState()
    var time by remember { mutableStateOf(fmt("HH:mm")) }
    val battery = rememberBattery()
    val homeIn = remember { Animatable(0f) }

    LaunchedEffect(showIntro) { if (!showIntro) homeIn.animateTo(1f, tween(600)) }
    LaunchedEffect(Unit) { while (true) { time = fmt("HH:mm"); delay(15_000) } }
    LaunchedEffect(tab, searching, query) {
        selected = 0
        if (shown.isNotEmpty()) listState.scrollToItem(0)
    }
    LaunchedEffect(safeSel) {
        if (shown.isNotEmpty()) listState.animateScrollToItem(safeSel)
    }
    BackHandler {
        when {
            settingsOpen -> settingsOpen = false
            searching -> { hideKeyboard(view); searching = false; query = "" }
            else -> { /* launcher: stay home */ }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        // ---- Background ----
        if (bgMode == 2 && bgImage != null) {
            Image(
                bitmap = bgImage, contentDescription = null,
                modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
            )
            Box(Modifier.fillMaxSize().background(Color(0x99000000)))
        } else {
            Box(
                Modifier.fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color(0xFF0B0B0C), Color.Black)))
            )
            if (bgMode == 0) GamingBackground()
            Box(
                Modifier.fillMaxSize().background(
                    Brush.radialGradient(
                        colors = listOf(Gold.copy(alpha = 0.10f), Color.Transparent),
                        center = Offset(300f, 0f), radius = 1300f
                    )
                )
            )
        }

        // ---- Content ----
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 36.dp, vertical = 18.dp)
                .graphicsLayer {
                    alpha = homeIn.value
                    translationY = (1f - homeIn.value) * 60f
                }
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("deckhome", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(16.dp))
                Box(Modifier.weight(1f)) {
                    if (searching) {
                        SearchField(
                            onQuery = { query = it },
                            onDone = { hideKeyboard(view) }
                        )
                    } else {
                        Row(Modifier.horizontalScroll(tabScroll)) {
                            tabs.forEachIndexed { i, name ->
                                TabItem(name, i == tab) {
                                    if (tab != i) { tab = i; sfx(SFX_CLICK) }
                                }
                                Spacer(Modifier.width(4.dp))
                            }
                        }
                    }
                }
                Spacer(Modifier.width(10.dp))
                Pill(if (searching) "CLOSE" else "SEARCH", searching) {
                    sfx(SFX_CLICK)
                    if (searching) { hideKeyboard(view); searching = false; query = "" }
                    else searching = true
                }
                Spacer(Modifier.width(8.dp))
                Pill("SETTINGS", false) { sfx(SFX_CLICK); settingsOpen = true }
                Spacer(Modifier.width(12.dp))
                if (battery >= 0) {
                    Text("$battery%", color = TextDim, fontSize = 12.sp)
                    Spacer(Modifier.width(10.dp))
                }
                Text(time, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }

            Spacer(Modifier.weight(1f))

            val title = shown.getOrNull(safeSel)?.label
                ?: if (tab == 1 && !searching) "No favorites yet" else "No apps found"
            Text(
                title,
                color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(start = 12.dp)
            )
            Text(
                (if (searching) "SEARCH" else tabs[tab]) + "  \u2022  ${shown.size}",
                color = Gold, fontSize = 12.sp, letterSpacing = 2.sp,
                modifier = Modifier.padding(start = 12.dp, top = 2.dp, bottom = 10.dp)
            )

            LazyRow(
                state = listState,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                itemsIndexed(shown, key = { _, a -> a.pkg }) { i, app ->
                    AppCard(
                        app = app,
                        isSelected = i == safeSel,
                        isFav = app.pkg in favorites,
                        onFocus = { if (selected != i) { selected = i; sfx(SFX_MOVE) } },
                        onClick = {
                            selected = i
                            sfx(SFX_OPEN)
                            ctx.packageManager.getLaunchIntentForPackage(app.pkg)
                                ?.let { ctx.startActivity(it) }
                        },
                        onLongClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            sfx(SFX_CLICK)
                            onToggleFav(app.pkg)
                        }
                    )
                }
            }

            Spacer(Modifier.weight(1f))

            Text(
                "Tap  Open      Hold  Star      D-pad  Navigate",
                color = TextDim, fontSize = 12.sp,
                modifier = Modifier.padding(start = 12.dp)
            )
        }

        // ---- Settings ----
        AnimatedVisibility(
            visible = settingsOpen,
            enter = fadeIn(tween(200)) + scaleIn(tween(200), initialScale = 0.92f),
            exit = fadeOut(tween(150))
        ) {
            SettingsPanel(
                musicOn = musicOn,
                onToggleMusic = { sfx(SFX_CLICK); onToggleMusic() },
                bgMode = bgMode,
                hasPhoto = bgImage != null,
                onBgMode = { sfx(SFX_CLICK); onBgMode(it) },
                onPickPhoto = { sfx(SFX_CLICK); onPickPhoto() },
                onClose = { sfx(SFX_CLICK); settingsOpen = false }
            )
        }

        // ---- Intro ----
        if (showIntro) {
            Intro(onRollEnd = { sfx(SFX_OPEN) }, onFinished = { showIntro = false })
        }
    }
}

// ---------------------------------------------------------------- Intro

@Composable
fun Intro(onRollEnd: () -> Unit, onFinished: () -> Unit) {
    val roll = remember { Animatable(0f) }
    val fade = remember { Animatable(1f) }
    var typed by remember { mutableStateOf("") }
    val name = "deckhome"

    LaunchedEffect(Unit) {
        roll.animateTo(1f, tween(1100, easing = FastOutSlowInEasing))
        onRollEnd()
        for (i in 1..name.length) { typed = name.take(i); delay(75) }
        delay(500)
        fade.animateTo(0f, tween(500))
        onFinished()
    }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = fade.value }
            .background(Color.Black)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                onFinished()
            },
        contentAlignment = Alignment.Center
    ) {
        val w = constraints.maxWidth.toFloat()
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "M", color = Gold, fontSize = 100.sp, fontWeight = FontWeight.Black,
                modifier = Modifier.graphicsLayer {
                    val left = 1f - roll.value
                    translationX = -left * w * 0.6f
                    rotationZ = -left * 720f
                    alpha = min(1f, roll.value * 4f)
                }
            )
            Text(
                typed, color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold,
                letterSpacing = 6.sp, maxLines = 1,
                modifier = Modifier.height(36.dp)
            )
        }
    }
}

// ---------------------------------------------------------------- Background

private data class Particle(
    val type: Int, val x0: Float, val y0: Float, val speed: Int, val dir: Int,
    val size: Float, val rot0: Float, val rotSpeed: Int,
    val amp: Float, val ph: Float, val m: Int, val alpha: Float
)

@Composable
fun GamingBackground() {
    val particles = remember {
        val r = kotlin.random.Random(11)
        List(26) {
            Particle(
                type = r.nextInt(7), x0 = r.nextFloat(), y0 = r.nextFloat(),
                speed = 1 + r.nextInt(2), dir = if (r.nextBoolean()) 1 else -1,
                size = 8f + r.nextFloat() * 14f, rot0 = r.nextFloat() * 360f,
                rotSpeed = r.nextInt(5) - 2, amp = 0.02f + r.nextFloat() * 0.05f,
                ph = r.nextFloat(), m = 1 + r.nextInt(3), alpha = 0.10f + r.nextFloat() * 0.18f
            )
        }
    }
    val transition = rememberInfiniteTransition(label = "bg")
    val t by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(90_000, easing = LinearEasing)),
        label = "t"
    )
    Canvas(Modifier.fillMaxSize()) {
        val tt = t
        val d = density
        val stroke = Stroke(width = 1.6f * d, cap = StrokeCap.Round, join = StrokeJoin.Round)
        particles.forEach { p ->
            val px = ((((p.x0 + p.dir * p.speed * tt) % 1f) + 1f) % 1f) * size.width
            val py = (p.y0 + p.amp * sin(2.0 * PI * (p.m * tt + p.ph)).toFloat()) * size.height
            val s = p.size * d
            val h = s / 2f
            val c = Gold.copy(alpha = p.alpha)
            rotate(p.rot0 + 360f * p.rotSpeed * tt, Offset(px, py)) {
                when (p.type) {
                    0 -> drawCircle(c, h, Offset(px, py), style = stroke)
                    1 -> drawRect(c, Offset(px - h, py - h), Size(s, s), style = stroke)
                    2 -> {
                        val path = Path().apply {
                            moveTo(px, py - h); lineTo(px + h, py + h * 0.8f)
                            lineTo(px - h, py + h * 0.8f); close()
                        }
                        drawPath(path, c, style = stroke)
                    }
                    3 -> {
                        drawLine(c, Offset(px - h, py - h), Offset(px + h, py + h), stroke.width, StrokeCap.Round)
                        drawLine(c, Offset(px - h, py + h), Offset(px + h, py - h), stroke.width, StrokeCap.Round)
                    }
                    4 -> {
                        drawLine(c, Offset(px - h, py), Offset(px + h, py), stroke.width * 1.6f, StrokeCap.Round)
                        drawLine(c, Offset(px, py - h), Offset(px, py + h), stroke.width * 1.6f, StrokeCap.Round)
                    }
                    5 -> {
                        val path = Path().apply {
                            moveTo(px, py - h); lineTo(px + h, py)
                            lineTo(px, py + h); lineTo(px - h, py); close()
                        }
                        drawPath(path, c, style = stroke)
                    }
                    else -> drawCircle(c, s * 0.14f, Offset(px, py))
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Pieces

@Composable
fun SearchField(onQuery: (String) -> Unit, onDone: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .clip(shape)
            .border(1.dp, Gold, shape)
            .background(Color(0x22FFC629))
            .padding(horizontal = 12.dp)
    ) {
        AndroidView(
            modifier = Modifier.width(230.dp).height(38.dp),
            factory = { c ->
                EditText(c).apply {
                    hint = "Search apps..."
                    setHintTextColor(0x99FFC629.toInt())
                    setTextColor(0xFFFFFFFF.toInt())
                    textSize = 15f
                    setSingleLine(true)
                    background = null
                    inputType = InputType.TYPE_CLASS_TEXT
                    imeOptions = EditorInfo.IME_ACTION_SEARCH or EditorInfo.IME_FLAG_NO_EXTRACT_UI
                    addTextChangedListener(object : TextWatcher {
                        override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                        override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                        override fun afterTextChanged(s: Editable?) { onQuery(s?.toString().orEmpty()) }
                    })
                    setOnEditorActionListener { _, _, _ -> onDone(); true }
                    post {
                        requestFocus()
                        (c.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                            .showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
                    }
                }
            }
        )
    }
}

@Composable
fun Pill(text: String, filled: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Text(
        text,
        color = if (filled) Ink else Gold,
        fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, maxLines = 1,
        modifier = Modifier
            .clip(shape)
            .background(if (filled) Gold else Color.Transparent)
            .border(1.dp, Gold, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 5.dp)
    )
}

@Composable
fun TabItem(name: String, active: Boolean, onClick: () -> Unit) {
    val color by animateColorAsState(if (active) Gold else TextDim, label = "tabColor")
    val barWidth by animateDpAsState(if (active) 24.dp else 0.dp, label = "tabBar")
    Column(
        Modifier
            .clip(RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(name, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, maxLines = 1)
        Box(Modifier.padding(top = 3.dp).height(2.dp).width(barWidth).background(Gold))
    }
}

@Composable
fun StarBadge(modifier: Modifier = Modifier) {
    Canvas(modifier.size(20.dp)) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val outer = size.minDimension / 2f
        val inner = outer * 0.42f
        val path = Path()
        for (i in 0 until 10) {
            val r = if (i % 2 == 0) outer else inner
            val a = -PI / 2 + i * PI / 5
            val x = cx + (r * kotlin.math.cos(a)).toFloat()
            val y = cy + (r * sin(a)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        drawPath(path, Gold)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppCard(
    app: AppItem,
    isSelected: Boolean,
    isFav: Boolean,
    onFocus: () -> Unit,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val target = if (pressed) 0.94f else if (isSelected) 1.12f else 1f
    val scale by animateFloatAsState(
        target,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "cardScale"
    )
    val shape = RoundedCornerShape(14.dp)
    Box(
        Modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .width(130.dp)
            .height(175.dp)
            .shadow(if (isSelected) 18.dp else 0.dp, shape, ambientColor = Gold, spotColor = Gold)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(app.tint.copy(alpha = 0.32f), Panel)))
            .border(
                width = if (isSelected) 3.dp else 1.dp,
                color = if (isSelected) Gold else Color(0x26FFFFFF),
                shape = shape
            )
            .onFocusChanged { if (it.isFocused) onFocus() }
            .combinedClickable(
                interactionSource = interaction,
                indication = null,
                onClick = onClick,
                onLongClick = onLongClick
            )
    ) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Image(app.icon, app.label, Modifier.size(80.dp))
            Text(
                app.label, color = Color.White, fontSize = 13.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
            )
        }
        if (isFav) StarBadge(Modifier.align(Alignment.TopEnd).padding(8.dp))
    }
}

@Composable
fun SettingsPanel(
    musicOn: Boolean,
    onToggleMusic: () -> Unit,
    bgMode: Int,
    hasPhoto: Boolean,
    onBgMode: (Int) -> Unit,
    onPickPhoto: () -> Unit,
    onClose: () -> Unit
) {
    val scrimSrc = remember { MutableInteractionSource() }
    val panelSrc = remember { MutableInteractionSource() }
    val shape = RoundedCornerShape(18.dp)
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .clickable(interactionSource = scrimSrc, indication = null, onClick = onClose),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .fillMaxWidth(0.7f)
                .widthIn(max = 460.dp)
                .heightIn(max = 300.dp)
                .clip(shape)
                .background(Panel)
                .border(1.dp, Gold, shape)
                .clickable(interactionSource = panelSrc, indication = null) { }
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("SETTINGS", color = Gold, fontSize = 16.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Spacer(Modifier.weight(1f))
                Pill("CLOSE", false, onClose)
            }
            Spacer(Modifier.height(18.dp))
            Text("MUSIC", color = TextDim, fontSize = 11.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(8.dp))
            Pill(if (musicOn) "MUSIC ON" else "MUSIC OFF", musicOn, onToggleMusic)
            Spacer(Modifier.height(18.dp))
            Text("BACKGROUND", color = TextDim, fontSize = 11.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(8.dp))
            Row {
                Pill("GAMING", bgMode == 0) { onBgMode(0) }
                Spacer(Modifier.width(8.dp))
                Pill("BLACK", bgMode == 1) { onBgMode(1) }
                Spacer(Modifier.width(8.dp))
                Pill("PHOTO", bgMode == 2 && hasPhoto) {
                    if (hasPhoto) onBgMode(2) else onPickPhoto()
                }
            }
            Spacer(Modifier.height(12.dp))
            Pill("CHOOSE PHOTO FROM GALLERY", false, onPickPhoto)
        }
    }
}
