package com.mzenix.deckhome

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AppItem(val label: String, val pkg: String, val icon: ImageBitmap)

private val Blue = Color(0xFF1A9FFF)
private val Card = Color(0xFF23303F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        val apps = loadApps()
        setContent { DeckHome(apps) }
    }

    private fun loadApps(): List<AppItem> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                AppItem(
                    label = it.loadLabel(pm).toString(),
                    pkg = it.activityInfo.packageName,
                    icon = it.loadIcon(pm).toBitmap(256, 256).asImageBitmap()
                )
            }
            .sortedBy { it.label.lowercase() }
    }
}

private fun now(): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

@Composable
fun DeckHome(apps: List<AppItem>) {
    val ctx = LocalContext.current
    var selected by remember { mutableIntStateOf(0) }
    val listState = rememberLazyListState()
    var time by remember { mutableStateOf(now()) }

    LaunchedEffect(Unit) { while (true) { time = now(); delay(15_000) } }
    LaunchedEffect(selected) { if (apps.isNotEmpty()) listState.animateScrollToItem(selected) }
    BackHandler { /* launcher: stay home */ }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1B2838), Color(0xFF0B0F14))))
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("HOME", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(time, color = Color(0xFFB8C4D0), fontSize = 20.sp)
        }

        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            LazyRow(
                state = listState,
                contentPadding = PaddingValues(horizontal = 48.dp),
                horizontalArrangement = Arrangement.spacedBy(24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                itemsIndexed(apps) { i, app ->
                    AppCard(
                        app = app,
                        isSelected = i == selected,
                        onFocus = { selected = i },
                        onClick = {
                            ctx.packageManager.getLaunchIntentForPackage(app.pkg)
                                ?.let { ctx.startActivity(it) }
                        }
                    )
                }
            }
            Spacer(Modifier.height(28.dp))
            Text(
                apps.getOrNull(selected)?.label ?: "",
                color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.SemiBold
            )
        }

        Text(
            "A  Open     D-pad  Navigate",
            color = Color(0xFF8A99A8), fontSize = 14.sp,
            modifier = Modifier.align(Alignment.BottomStart).padding(32.dp)
        )
    }
}

@Composable
fun AppCard(app: AppItem, isSelected: Boolean, onFocus: () -> Unit, onClick: () -> Unit) {
    val scale by animateFloatAsState(if (isSelected) 1.12f else 1f, label = "scale")
    Box(
        Modifier
            .scale(scale)
            .size(width = 150.dp, height = 200.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Card)
            .border(
                width = if (isSelected) 3.dp else 0.dp,
                color = Blue,
                shape = RoundedCornerShape(10.dp)
            )
            .onFocusChanged { if (it.isFocused) onFocus() }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Image(app.icon, app.label, Modifier.size(96.dp))
    }
}
