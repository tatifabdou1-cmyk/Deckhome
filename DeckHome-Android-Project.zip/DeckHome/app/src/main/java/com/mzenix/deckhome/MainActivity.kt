package com.mzenix.deckhome

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

// ------------------------------------------------------------------ Model

data class AppItem(
    val label: String,
    val pkg: String,
    val icon: ImageBitmap,
    val tint: Color,
    val isGame: Boolean
)

data class HomeState(
    val musicOn: Boolean,
    val track: Int,
    val customName: String?,
    val favorites: Set<String>,
    val bgMode: Int,
    val bgImage: ImageBitmap?,
    val accent: Int,
    val signOn: Boolean,
    val signStyle: Int,
    val signText: String,
    val lang: Int
)

class HomeActions(
    val toggleMusic: () -> Unit,
    val chooseTrack: (Int) -> Unit,
    val pickMusic: () -> Unit,
    val toggleFav: (String) -> Unit,
    val chooseBg: (Int) -> Unit,
    val pickPhoto: () -> Unit,
    val chooseAccent: (Int) -> Unit,
    val toggleSign: () -> Unit,
    val chooseSignStyle: (Int) -> Unit,
    val saveSignText: (String) -> Unit,
    val chooseLang: (Int) -> Unit,
    val sfx: (Int) -> Unit,
    val exitApp: () -> Unit
)

private val ACCENTS = listOf(
    Color(0xFFFFC629), // yellow
    Color(0xFFFF4D4D), // red
    Color(0xFF34D96B), // green
    Color(0xFF3D9BFF), // blue
    Color(0xFFFF5FA8), // pink
    Color(0xFFA66BFF), // purple
    Color(0xFF25E3E3)  // cyan
)
private val ACCENT_NAMES = listOf("YELLOW", "RED", "GREEN", "BLUE", "PINK", "PURPLE", "CYAN")

private val accentState = mutableStateOf(ACCENTS[0])
private val Gold: Color get() = accentState.value
private val Panel = Color(0xFF111112)
private val TextDim = Color(0xFF9A9A9A)
private val Ink = Color(0xFF050505)

private const val SFX_MOVE = 0
private const val SFX_CLICK = 1
private const val SFX_OPEN = 2
private const val SFX_FAV_ON = 3
private const val SFX_FAV_OFF = 4
private const val SFX_LAUNCH = 5

// ------------------------------------------------------------------ Translations
// Languages: 0 = English (default), 1 = Arabic, 2 = Spanish, 3 = French.

private val langState = mutableIntStateOf(0)

private const val HINT_KEYS = "Tap  Open      Hold  Star      D-pad  Navigate"
private const val HINT_BG =
    "Gaming: floating symbols.  Rain: calm falling rain.  Chaos: aliens, zzz and fight clouds."

private val I18N: Map<String, List<String>> = mapOf(
    // [Arabic, Spanish, French]
    "ALL" to listOf("الكل", "TODO", "TOUT"),
    "FAV" to listOf("المفضلة", "FAV", "FAV"),
    "GAMES" to listOf("ألعاب", "JUEGOS", "JEUX"),
    "APPS" to listOf("تطبيقات", "APPS", "APPS"),
    "SEARCH" to listOf("بحث", "BUSCAR", "CHERCHER"),
    "CLOSE" to listOf("إغلاق", "CERRAR", "FERMER"),
    "DONE" to listOf("تم", "LISTO", "OK"),
    "Search apps..." to listOf("ابحث عن تطبيق...", "Buscar apps...", "Rechercher des apps..."),
    "No favorites yet" to listOf("لا توجد مفضلة بعد", "Aún no hay favoritos", "Pas encore de favoris"),
    "No apps found" to listOf("لا توجد تطبيقات", "No se encontraron apps", "Aucune app trouvée"),
    HINT_KEYS to listOf(
        "اضغط: فتح      اضغط مطولاً: نجمة      الأسهم: تنقل",
        "Toca: abrir      Mantén: estrella      D-pad: moverse",
        "Appuyer : ouvrir      Maintenir : étoile      D-pad : naviguer"
    ),
    "DO YOU WANT EXIT" to listOf("هل تريد الخروج؟", "¿QUIERES SALIR?", "VOULEZ-VOUS QUITTER ?"),
    "STAY" to listOf("ابقَ", "QUEDARSE", "RESTER"),
    "WELCOME" to listOf("أهلاً بك", "BIENVENIDO", "BIENVENUE"),
    "Good night" to listOf("تصبح على خير", "Buenas noches", "Bonne nuit"),
    "Good morning" to listOf("صباح الخير", "Buenos días", "Bonjour"),
    "Good afternoon" to listOf("طاب يومك", "Buenas tardes", "Bon après-midi"),
    "Good evening" to listOf("مساء الخير", "Buenas noches", "Bonsoir"),
    "Have a nice day" to listOf("أتمنى لك يوماً سعيداً", "Que tengas un buen día", "Passe une bonne journée"),
    "SETTINGS" to listOf("الإعدادات", "AJUSTES", "PARAMÈTRES"),
    "Customize deckhome" to listOf("خصّص deckhome", "Personaliza deckhome", "Personnalise deckhome"),
    "MUSIC" to listOf("الموسيقى", "MÚSICA", "MUSIQUE"),
    "BACKGROUND" to listOf("الخلفية", "FONDO", "ARRIÈRE-PLAN"),
    "THEME" to listOf("السمة", "TEMA", "THÈME"),
    "SIGN" to listOf("اللافتة", "LETRERO", "PANNEAU"),
    "LANGUAGE" to listOf("اللغة", "IDIOMA", "LANGUE"),
    "PLAYBACK" to listOf("التشغيل", "REPRODUCCIÓN", "LECTURE"),
    "Background music" to listOf("موسيقى الخلفية", "Música de fondo", "Musique de fond"),
    "Plays while deckhome is open" to listOf(
        "تعمل أثناء فتح deckhome", "Suena mientras deckhome está abierto", "Joue tant que deckhome est ouvert"
    ),
    "TRACK" to listOf("المقطوعة", "PISTA", "PISTE"),
    "Drift" to listOf("انجراف", "Deriva", "Dérive"),
    "Dawn" to listOf("فجر", "Amanecer", "Aube"),
    "Midnight" to listOf("منتصف الليل", "Medianoche", "Minuit"),
    "Glow" to listOf("توهّج", "Resplandor", "Éclat"),
    "Custom" to listOf("مخصصة", "Personalizada", "Personnalisée"),
    "Custom (none yet)" to listOf("مخصصة (لا يوجد بعد)", "Personalizada (ninguna aún)", "Personnalisée (aucune)"),
    "CHOOSE MUSIC FILE" to listOf("اختر ملف موسيقى", "ELEGIR ARCHIVO DE MÚSICA", "CHOISIR UN FICHIER MUSICAL"),
    "STYLE" to listOf("النمط", "ESTILO", "STYLE"),
    "GAMING" to listOf("ألعاب", "GAMING", "GAMING"),
    "RAIN" to listOf("مطر", "LLUVIA", "PLUIE"),
    "CHAOS" to listOf("فوضى", "CAOS", "CHAOS"),
    "PHOTO" to listOf("صورة", "FOTO", "PHOTO"),
    HINT_BG to listOf(
        "ألعاب: رموز عائمة.  مطر: مطر هادئ.  فوضى: فضائيون وZzz وسحب شجار.",
        "Gaming: símbolos flotantes.  Lluvia: lluvia tranquila.  Caos: aliens, zzz y nubes de pelea.",
        "Gaming : symboles flottants.  Pluie : pluie calme.  Chaos : aliens, zzz et nuages de bagarre."
    ),
    "YOUR PHOTO" to listOf("صورتك", "TU FOTO", "TA PHOTO"),
    "CHOOSE PHOTO FROM GALLERY" to listOf(
        "اختر صورة من المعرض", "ELEGIR FOTO DE LA GALERÍA", "CHOISIR UNE PHOTO DE LA GALERIE"
    ),
    "COLOR WHEEL" to listOf("عجلة الألوان", "RUEDA DE COLOR", "ROUE DES COULEURS"),
    "YELLOW" to listOf("أصفر", "AMARILLO", "JAUNE"),
    "RED" to listOf("أحمر", "ROJO", "ROUGE"),
    "GREEN" to listOf("أخضر", "VERDE", "VERT"),
    "BLUE" to listOf("أزرق", "AZUL", "BLEU"),
    "PINK" to listOf("وردي", "ROSA", "ROSE"),
    "PURPLE" to listOf("بنفسجي", "MORADO", "VIOLET"),
    "CYAN" to listOf("سماوي", "CIAN", "CYAN"),
    "Tap a slice to recolor the whole app" to listOf(
        "المس أي قطعة لتغيير لون التطبيق كله",
        "Toca una porción para cambiar el color de toda la app",
        "Touche une part pour recolorer toute l'app"
    ),
    "PREVIEW" to listOf("معاينة", "VISTA PREVIA", "APERÇU"),
    "Sign is hidden" to listOf("اللافتة مخفية", "El letrero está oculto", "Le panneau est masqué"),
    "Show sign" to listOf("إظهار اللافتة", "Mostrar letrero", "Afficher le panneau"),
    "Shown next to the app title" to listOf(
        "تظهر بجانب عنوان التطبيق", "Se muestra junto al título de la app", "Affiché à côté du titre de l'app"
    ),
    "SIGN TEXT" to listOf("نص اللافتة", "TEXTO DEL LETRERO", "TEXTE DU PANNEAU"),
    "EDIT TEXT" to listOf("تعديل النص", "EDITAR TEXTO", "MODIFIER LE TEXTE"),
    "Max 9 characters" to listOf("9 أحرف كحد أقصى", "Máximo 9 caracteres", "9 caractères maximum"),
    "Type your sign text" to listOf("اكتب نص اللافتة", "Escribe el texto del letrero", "Écris le texte du panneau"),
    "SIGN STYLE" to listOf("شكل اللافتة", "ESTILO DEL LETRERO", "STYLE DU PANNEAU")
)

private fun tr(en: String): String {
    val i = langState.intValue
    if (i <= 0) return en
    return I18N[en]?.getOrNull(i - 1) ?: en
}

// Arabic letters must stay connected, so letter spacing is switched off for Arabic.
private fun ls(v: Float): TextUnit = if (langState.intValue == 1) 0.sp else v.sp

// ------------------------------------------------------------------ Activity

class MainActivity : ComponentActivity() {

    private var player: MediaPlayer? = null
    private var sounds: SoundPool? = null
    private var sMove = 0
    private var sClick = 0
    private var sOpen = 0
    private var sFavOn = 0
    private var sFavOff = 0
    private var sLaunch = 0
    private val trackRes = intArrayOf(
        R.raw.ambient, R.raw.music_dawn, R.raw.music_midnight, R.raw.music_glow
    )

    private var musicOn by mutableStateOf(true)
    private var favorites by mutableStateOf(setOf<String>())
    private var bgMode by mutableIntStateOf(0)
    private var bgImage by mutableStateOf<ImageBitmap?>(null)
    private var trackIdx by mutableIntStateOf(0)
    private var customName by mutableStateOf<String?>(null)
    private var accentIdx by mutableIntStateOf(0)
    private var signOn by mutableStateOf(true)
    private var signStyleIdx by mutableIntStateOf(0)
    private var signTextState by mutableStateOf("Enjoy")
    private var langIdx by mutableIntStateOf(0)
    private val prefs by lazy { getSharedPreferences("deckhome", MODE_PRIVATE) }

    private val photoPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: Exception) { }
                val img = loadBg(uri)
                if (img != null) {
                    bgImage = img
                    prefs.edit().putString("bg_uri", uri.toString()).apply()
                    changeBgMode(2)
                }
            }
        }

    private val musicPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (e: Exception) { }
                val name = queryName(uri)
                prefs.edit()
                    .putString("custom_uri", uri.toString())
                    .putString("custom_name", name)
                    .apply()
                customName = name
                chooseTrack(4)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        musicOn = prefs.getBoolean("music", true)
        favorites = prefs.getStringSet("fav", emptySet())?.toSet() ?: emptySet()
        bgMode = prefs.getInt("bg_mode", 0).coerceIn(0, 3)
        prefs.getString("bg_uri", null)?.let { bgImage = loadBg(Uri.parse(it)) }
        trackIdx = prefs.getInt("track", 0)
        customName = prefs.getString("custom_name", null)
        accentIdx = prefs.getInt("accent", 0).coerceIn(0, ACCENTS.lastIndex)
        accentState.value = ACCENTS[accentIdx]
        signOn = prefs.getBoolean("sign_on", true)
        signStyleIdx = prefs.getInt("sign_style", 0).coerceIn(0, 5)
        signTextState = (prefs.getString("sign_text", "Enjoy") ?: "Enjoy").take(9)
        langIdx = prefs.getInt("lang", 0).coerceIn(0, 3)
        langState.intValue = langIdx

        initSounds()
        loadTrack(play = false)

        val apps = loadApps()
        val actions = HomeActions(
            toggleMusic = { toggleMusic() },
            chooseTrack = { chooseTrack(it) },
            pickMusic = { musicPicker.launch(arrayOf("audio/*")) },
            toggleFav = { toggleFavorite(it) },
            chooseBg = { changeBgMode(it) },
            pickPhoto = { photoPicker.launch(arrayOf("image/*")) },
            chooseAccent = { chooseAccent(it) },
            toggleSign = { toggleSign() },
            chooseSignStyle = { chooseSignStyle(it) },
            saveSignText = { saveSignText(it) },
            chooseLang = { chooseLang(it) },
            sfx = { sfx(it) },
            exitApp = { finish() }
        )
        setContent {
            DeckHome(
                apps = apps,
                st = HomeState(
                    musicOn = musicOn,
                    track = trackIdx,
                    customName = customName,
                    favorites = favorites,
                    bgMode = bgMode,
                    bgImage = bgImage,
                    accent = accentIdx,
                    signOn = signOn,
                    signStyle = signStyleIdx,
                    signText = signTextState,
                    lang = langIdx
                ),
                act = actions
            )
        }
    }

    override fun onStart() {
        super.onStart()
        if (musicOn) player?.start()
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release(); player = null
        sounds?.release(); sounds = null
    }

    // ---- audio ----

    private fun initSounds() {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        sounds = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build().also {
            sMove = it.load(this, R.raw.sfx_move, 1)
            sClick = it.load(this, R.raw.sfx_click, 1)
            sOpen = it.load(this, R.raw.sfx_open, 1)
            sFavOn = it.load(this, R.raw.sfx_fav_on, 1)
            sFavOff = it.load(this, R.raw.sfx_fav_off, 1)
            sLaunch = it.load(this, R.raw.sfx_launch, 1)
        }
    }

    private fun loadTrack(play: Boolean) {
        player?.release()
        player = null
        var p: MediaPlayer? = null
        if (trackIdx == 4) {
            val u = prefs.getString("custom_uri", null)
            if (u != null) {
                p = try {
                    MediaPlayer().apply {
                        setDataSource(this@MainActivity, Uri.parse(u))
                        prepare()
                    }
                } catch (e: Exception) {
                    null
                }
            }
        }
        if (p == null) {
            if (trackIdx == 4) trackIdx = 0
            p = MediaPlayer.create(this, trackRes[trackIdx.coerceIn(0, trackRes.lastIndex)])
        }
        p?.isLooping = true
        p?.setVolume(0.28f, 0.28f)
        player = p
        if (play) p?.start()
    }

    private fun chooseTrack(i: Int) {
        trackIdx = i
        prefs.edit().putInt("track", i).apply()
        loadTrack(play = musicOn)
    }

    private fun toggleMusic() {
        musicOn = !musicOn
        prefs.edit().putBoolean("music", musicOn).apply()
        if (musicOn) player?.start() else player?.pause()
    }

    private fun sfx(kind: Int) {
        val id = when (kind) {
            SFX_MOVE -> sMove
            SFX_OPEN -> sOpen
            SFX_FAV_ON -> sFavOn
            SFX_FAV_OFF -> sFavOff
            SFX_LAUNCH -> sLaunch
            else -> sClick
        }
        sounds?.play(id, 0.8f, 0.8f, 1, 0, 1f)
    }

    // ---- settings ----

    private fun toggleFavorite(pkg: String) {
        favorites = if (pkg in favorites) favorites - pkg else favorites + pkg
        prefs.edit().putStringSet("fav", HashSet(favorites)).apply()
    }

    private fun changeBgMode(mode: Int) {
        bgMode = mode
        prefs.edit().putInt("bg_mode", mode).apply()
    }

    private fun chooseAccent(i: Int) {
        val v = i.coerceIn(0, ACCENTS.lastIndex)
        accentIdx = v
        accentState.value = ACCENTS[v]
        prefs.edit().putInt("accent", v).apply()
    }

    private fun toggleSign() {
        signOn = !signOn
        prefs.edit().putBoolean("sign_on", signOn).apply()
    }

    private fun chooseSignStyle(i: Int) {
        signStyleIdx = i.coerceIn(0, 5)
        prefs.edit().putInt("sign_style", signStyleIdx).apply()
    }

    private fun saveSignText(raw: String) {
        val t = raw.trim().take(9)
        signTextState = t
        prefs.edit().putString("sign_text", t).apply()
    }

    private fun chooseLang(i: Int) {
        val v = i.coerceIn(0, 3)
        langIdx = v
        langState.intValue = v
        prefs.edit().putInt("lang", v).apply()
    }

    private fun queryName(uri: Uri): String = try {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (col >= 0 && c.moveToFirst()) c.getString(col) else null
        } ?: "Custom track"
    } catch (e: Exception) {
        "Custom track"
    }

    private fun loadBg(uri: Uri): ImageBitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 2000 || bounds.outHeight / sample > 2000) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?.asImageBitmap()
    } catch (e: Exception) {
        null
    }

    @Suppress("DEPRECATION")
    private fun loadApps(): List<AppItem> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                val bmp = it.loadIcon(pm).toBitmap(192, 192)
                val px = Bitmap.createScaledBitmap(bmp, 1, 1, true).getPixel(0, 0)
                val ai = it.activityInfo.applicationInfo
                AppItem(
                    label = it.loadLabel(pm).toString(),
                    pkg = it.activityInfo.packageName,
                    icon = bmp.asImageBitmap(),
                    tint = Color(0xFF000000.toInt() or (px and 0xFFFFFF)),
                    isGame = ai.category == ApplicationInfo.CATEGORY_GAME ||
                        (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                )
            }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }
}

// ------------------------------------------------------------------ Helpers

private fun fmt(pattern: String): String =
    SimpleDateFormat(pattern, Locale.getDefault()).format(Date())

private fun hideKeyboard(v: View) {
    (v.context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
        .hideSoftInputFromWindow(v.windowToken, 0)
}

@Composable
fun rememberBattery(): Int {
    val ctx = LocalContext.current
    var level by remember { mutableIntStateOf(-1) }
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                if (l >= 0 && s > 0) level = l * 100 / s
            }
        }
        val sticky = ContextCompat.registerReceiver(
            ctx, receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        sticky?.let { receiver.onReceive(ctx, it) }
        onDispose { ctx.unregisterReceiver(receiver) }
    }
    return level
}

// ------------------------------------------------------------------ Home

@Composable
fun DeckHome(apps: List<AppItem>, st: HomeState, act: HomeActions) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val haptic = LocalHapticFeedback.current
    val tabs = listOf("ALL", "FAV", "GAMES", "APPS")
    var tab by remember { mutableIntStateOf(0) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var settingsOpen by remember { mutableStateOf(false) }
    var exitOpen by remember { mutableStateOf(false) }
    var signEditOpen by remember { mutableStateOf(false) }
    var stage by remember { mutableIntStateOf(0) } // 0 intro, 1 welcome, 2 home
    var introGone by remember { mutableStateOf(false) }
    var homeStart by remember { mutableStateOf(false) }
    val favorites = st.favorites

    val shown = remember(tab, apps, favorites, query, searching) {
        val base = when {
            searching ->
                if (query.isBlank()) apps
                else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
            tab == 1 -> apps.filter { it.pkg in favorites }
            tab == 2 -> apps.filter { it.isGame }
            tab == 3 -> apps.filter { !it.isGame }
            else -> apps
        }
        base.sortedByDescending { it.pkg in favorites }
    }

    var selected by remember { mutableIntStateOf(0) }
    val safeSel = if (shown.isEmpty()) 0 else selected.coerceIn(0, shown.lastIndex)
    val listState = rememberLazyListState()
    val tabScroll = rememberScrollState()
    var time by remember { mutableStateOf(fmt("HH:mm")) }
    val battery = rememberBattery()
    val homeIn = remember { Animatable(0f) }
    val rowAnim = remember { Animatable(1f) }

    LaunchedEffect(homeStart) {
        if (homeStart) homeIn.animateTo(1f, tween(1000, easing = FastOutSlowInEasing))
    }
    LaunchedEffect(Unit) { while (true) { time = fmt("HH:mm"); delay(15_000) } }
    LaunchedEffect(tab, searching) {
        rowAnim.snapTo(0f)
        rowAnim.animateTo(1f, tween(450, easing = FastOutSlowInEasing))
    }
    LaunchedEffect(tab, searching, query) {
        selected = 0
        if (shown.isNotEmpty()) listState.scrollToItem(0)
    }
    LaunchedEffect(safeSel) {
        if (shown.isNotEmpty()) listState.animateScrollToItem(safeSel)
    }
    BackHandler {
        when {
            signEditOpen -> signEditOpen = false
            exitOpen -> exitOpen = false
            settingsOpen -> settingsOpen = false
            searching -> { hideKeyboard(view); searching = false; query = "" }
            else -> { /* launcher: stay home */ }
        }
    }

    val photo = st.bgImage

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        // ---- Background ----
        if (st.bgMode == 2 && photo != null) {
            Image(
                bitmap = photo, contentDescription = null,
                modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
            )
            Box(Modifier.fillMaxSize().background(Color(0x99000000)))
        } else {
            Box(
                Modifier.fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color(0xFF0B0B0C), Color.Black)))
            )
            when (st.bgMode) {
                1 -> RainBackground()
                3 -> ChaosBackground()
                else -> GamingBackground()
            }
            Box(
                Modifier.fillMaxSize().background(
                    Brush.radialGradient(
                        colors = listOf(Gold.copy(alpha = 0.10f), Color.Transparent),
                        center = Offset(300f, 0f), radius = 1300f
                    )
                )
            )
        }

        // ---- Content ----
        Column(Modifier.fillMaxSize().padding(horizontal = 36.dp, vertical = 18.dp)) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .graphicsLayer {
                        alpha = homeIn.value
                        translationY = -(1f - homeIn.value) * 50f
                    },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("deckhome", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(16.dp))
                Box(Modifier.weight(1f)) {
                    if (searching) {
                        SearchField(onQuery = { query = it }, onDone = { hideKeyboard(view) })
                    } else {
                        Row(Modifier.horizontalScroll(tabScroll)) {
                            tabs.forEachIndexed { i, name ->
                                TabItem(tr(name), i == tab) {
                                    if (tab != i) { tab = i; act.sfx(SFX_CLICK) }
                                }
                                Spacer(Modifier.width(4.dp))
                            }
                        }
                    }
                }
                Spacer(Modifier.width(10.dp))
                Pill(if (searching) tr("CLOSE") else tr("SEARCH"), searching) {
                    act.sfx(SFX_CLICK)
                    if (searching) { hideKeyboard(view); searching = false; query = "" }
                    else searching = true
                }
                Spacer(Modifier.width(6.dp))
                GearIcon(settingsOpen) { act.sfx(SFX_CLICK); settingsOpen = true }
                PowerIcon { act.sfx(SFX_CLICK); exitOpen = true }
                Spacer(Modifier.width(8.dp))
                if (battery >= 0) {
                    Text("$battery%", color = TextDim, fontSize = 12.sp)
                    Spacer(Modifier.width(10.dp))
                }
                Text(time, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }

            Spacer(Modifier.weight(1f))

            val title = shown.getOrNull(safeSel)?.label
                ?: if (tab == 1 && !searching) tr("No favorites yet") else tr("No apps found")
            Row(
                Modifier
                    .fillMaxWidth()
                    .graphicsLayer {
                        alpha = homeIn.value
                        translationY = (1f - homeIn.value) * 40f
                    },
                verticalAlignment = Alignment.Bottom
            ) {
                Column(Modifier.weight(1f)) {
                    Crossfade(targetState = title, animationSpec = tween(260), label = "title") { t ->
                        Text(
                            t, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(start = 12.dp)
                        )
                    }
                    Text(
                        (if (searching) tr("SEARCH") else tr(tabs[tab])) + "  \u2022  ${shown.size}",
                        color = Gold, fontSize = 12.sp, letterSpacing = ls(2f),
                        modifier = Modifier.padding(start = 12.dp, top = 2.dp, bottom = 6.dp)
                    )
                }
                SignBadge(st)
            }

            LazyRow(
                state = listState,
                modifier = Modifier.graphicsLayer {
                    alpha = rowAnim.value
                    translationX = (1f - rowAnim.value) * 40f
                },
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                itemsIndexed(shown, key = { _, a -> a.pkg }) { i, app ->
                    AppCard(
                        app = app,
                        index = i,
                        visible = homeStart,
                        isSelected = i == safeSel,
                        isFav = app.pkg in favorites,
                        onFocus = { if (selected != i) { selected = i; act.sfx(SFX_MOVE) } },
                        onClick = {
                            selected = i
                            act.sfx(SFX_LAUNCH)
                            ctx.packageManager.getLaunchIntentForPackage(app.pkg)
                                ?.let { ctx.startActivity(it) }
                        },
                        onLongClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            val wasFav = app.pkg in favorites
                            act.toggleFav(app.pkg)
                            act.sfx(if (wasFav) SFX_FAV_OFF else SFX_FAV_ON)
                        }
                    )
                }
            }

            Spacer(Modifier.weight(1f))

            Text(
                tr(HINT_KEYS),
                color = TextDim, fontSize = 12.sp,
                modifier = Modifier
                    .padding(start = 12.dp)
                    .graphicsLayer { alpha = homeIn.value }
            )
        }

        // ---- Settings ----
        AnimatedVisibility(
            visible = settingsOpen,
            enter = fadeIn(tween(320, easing = FastOutSlowInEasing)) +
                scaleIn(tween(320, easing = FastOutSlowInEasing), initialScale = 0.94f),
            exit = fadeOut(tween(220)) + scaleOut(tween(220), targetScale = 0.96f)
        ) {
            SettingsPanel(
                st = st,
                act = act,
                onEditSign = { signEditOpen = true },
                onClose = { act.sfx(SFX_CLICK); settingsOpen = false }
            )
        }

        // ---- Sign text editor ----
        AnimatedVisibility(
            visible = signEditOpen,
            enter = fadeIn(tween(240, easing = FastOutSlowInEasing)) +
                scaleIn(tween(240, easing = FastOutSlowInEasing), initialScale = 0.94f),
            exit = fadeOut(tween(180)) + scaleOut(tween(180), targetScale = 0.97f)
        ) {
            SignEditor(
                initial = st.signText,
                onSave = { act.sfx(SFX_CLICK); act.saveSignText(it); signEditOpen = false },
                onCancel = { act.sfx(SFX_CLICK); signEditOpen = false }
            )
        }

        // ---- Exit dialog ----
        AnimatedVisibility(
            visible = exitOpen,
            enter = fadeIn(tween(260, easing = FastOutSlowInEasing)) +
                scaleIn(tween(260, easing = FastOutSlowInEasing), initialScale = 0.92f),
            exit = fadeOut(tween(200)) + scaleOut(tween(200), targetScale = 0.96f)
        ) {
            ExitDialog(
                onExit = { act.sfx(SFX_CLICK); act.exitApp() },
                onStay = { act.sfx(SFX_CLICK); exitOpen = false }
            )
        }

        // ---- Intro, then welcome (welcome fades in over the intro) ----
        if (stage == 0 || (stage == 1 && !introGone)) {
            Intro(onRollEnd = { act.sfx(SFX_OPEN) }, onFinished = { if (stage == 0) stage = 1 })
        }
        if (stage == 1) {
            Welcome(
                onCovered = { introGone = true },
                onFadeStart = { homeStart = true },
                onFinished = { homeStart = true; stage = 2 }
            )
        }
    }
}

// ------------------------------------------------------------------ Intro + Welcome

@Composable
fun Intro(onRollEnd: () -> Unit, onFinished: () -> Unit) {
    val roll = remember { Animatable(0f) }
    val ring = remember { Animatable(0f) }
    val land = remember { Animatable(0f) }
    val underline = remember { Animatable(0f) }
    var typed by remember { mutableStateOf("") }
    val name = "deckhome"

    LaunchedEffect(Unit) {
        delay(500)
        roll.animateTo(1f, tween(1600, easing = FastOutSlowInEasing))
        onRollEnd()
        launch { ring.animateTo(1f, tween(1100, easing = LinearOutSlowInEasing)) }
        launch { land.animateTo(1f, tween(550, easing = FastOutSlowInEasing)) }
        delay(150)
        for (i in 1..name.length) { typed = name.take(i); delay(120) }
        underline.animateTo(1f, tween(700, easing = FastOutSlowInEasing))
        delay(1300)
        onFinished()
    }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                onFinished()
            },
        contentAlignment = Alignment.Center
    ) {
        val w = constraints.maxWidth.toFloat()
        GamingBackground()
        Canvas(Modifier.fillMaxSize()) {
            val glow = 0.30f * roll.value.coerceIn(0f, 1f)
            val rad = size.minDimension * 0.6f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Gold.copy(alpha = glow), Color.Transparent),
                    center = center, radius = rad
                ),
                radius = rad, center = center
            )
            if (ring.value > 0f && ring.value < 1f) {
                drawCircle(
                    color = Gold.copy(alpha = (1f - ring.value) * 0.8f),
                    radius = ring.value * size.maxDimension * 0.5f,
                    center = center,
                    style = Stroke(width = 3.dp.toPx())
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(contentAlignment = Alignment.Center) {
                for (g in 3 downTo 1) {
                    Text(
                        "M", color = Gold, fontSize = 100.sp, fontWeight = FontWeight.Black,
                        modifier = Modifier.graphicsLayer {
                            val left = (1f - roll.value).coerceAtLeast(0f)
                            translationX = -left * w * 0.6f - g * left * 46f
                            rotationZ = -left * 900f - g * left * 30f
                            alpha = min(1f, roll.value * 4f) * (0.40f - g * 0.09f) *
                                min(1f, left * 4f)
                        }
                    )
                }
                Text(
                    "M", color = Gold, fontSize = 100.sp, fontWeight = FontWeight.Black,
                    modifier = Modifier.graphicsLayer {
                        val left = 1f - roll.value
                        val pulse = 1f + 0.18f * sin(PI * land.value).toFloat()
                        translationX = -left * w * 0.6f
                        rotationZ = -left * 900f
                        scaleX = pulse
                        scaleY = pulse
                        alpha = min(1f, roll.value * 4f)
                    }
                )
            }
            Text(
                typed, color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold,
                letterSpacing = 6.sp, maxLines = 1,
                modifier = Modifier.height(36.dp)
            )
            Box(Modifier.height(2.dp).width((150f * underline.value).dp).background(Gold))
        }
    }
}

@Composable
fun Welcome(onCovered: () -> Unit, onFadeStart: () -> Unit, onFinished: () -> Unit) {
    val appear = remember { Animatable(0f) }
    val sub = remember { Animatable(0f) }
    val line = remember { Animatable(0f) }
    val fade = remember { Animatable(0f) }
    val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
    val greeting = when {
        hour < 5 -> tr("Good night")
        hour < 12 -> tr("Good morning")
        hour < 18 -> tr("Good afternoon")
        else -> tr("Good evening")
    }
    val arabic = langState.intValue == 1

    LaunchedEffect(Unit) {
        fade.animateTo(1f, tween(650, easing = FastOutSlowInEasing))
        onCovered()
        launch { appear.animateTo(1f, tween(1000, easing = FastOutSlowInEasing)) }
        delay(500)
        launch { line.animateTo(1f, tween(700, easing = FastOutSlowInEasing)) }
        delay(300)
        sub.animateTo(1f, tween(600))
        delay(1300)
        onFadeStart()
        fade.animateTo(0f, tween(800, easing = FastOutSlowInEasing))
        onFinished()
    }

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = fade.value }
            .background(Color.Black)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                onFinished()
            },
        contentAlignment = Alignment.Center
    ) {
        GamingBackground()
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                tr("WELCOME"), color = Gold, fontSize = 38.sp, fontWeight = FontWeight.Bold,
                letterSpacing = if (arabic) 0.sp else (24f - 18f * appear.value).sp,
                modifier = Modifier.graphicsLayer {
                    alpha = appear.value
                    scaleX = 0.9f + 0.1f * appear.value
                    scaleY = 0.9f + 0.1f * appear.value
                }
            )
            Box(
                Modifier.padding(top = 10.dp).height(2.dp)
                    .width((160f * line.value).dp).background(Gold)
            )
            Text(
                "$greeting  \u2022  ${tr("Have a nice day")}",
                color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp, letterSpacing = ls(2f),
                modifier = Modifier
                    .padding(top = 12.dp)
                    .graphicsLayer {
                        alpha = sub.value
                        translationY = (1f - sub.value) * 16f
                    }
            )
        }
    }
}

// ------------------------------------------------------------------ Backgrounds

private data class Particle(
    val type: Int, val x0: Float, val y0: Float, val speed: Int, val dir: Int,
    val size: Float, val rot0: Float, val rotSpeed: Int,
    val amp: Float, val ph: Float, val m: Int, val alpha: Float
)

@Composable
fun GamingBackground() {
    val particles = remember {
        val r = kotlin.random.Random(11)
        List(26) {
            Particle(
                type = r.nextInt(7), x0 = r.nextFloat(), y0 = r.nextFloat(),
                speed = 1 + r.nextInt(2), dir = if (r.nextBoolean()) 1 else -1,
                size = 8f + r.nextFloat() * 14f, rot0 = r.nextFloat() * 360f,
                rotSpeed = r.nextInt(5) - 2, amp = 0.02f + r.nextFloat() * 0.05f,
                ph = r.nextFloat(), m = 1 + r.nextInt(3), alpha = 0.10f + r.nextFloat() * 0.18f
            )
        }
    }
    val transition = rememberInfiniteTransition(label = "bg")
    val t by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(90_000, easing = LinearEasing)),
        label = "t"
    )
    Canvas(Modifier.fillMaxSize()) {
        val tt = t
        val d = density
        val stroke = Stroke(width = 1.6f * d, cap = StrokeCap.Round, join = StrokeJoin.Round)
        particles.forEach { p ->
            val px = ((((p.x0 + p.dir * p.speed * tt) % 1f) + 1f) % 1f) * size.width
            val py = (p.y0 + p.amp * sin(2.0 * PI * (p.m * tt + p.ph)).toFloat()) * size.height
            val s = p.size * d
            val h = s / 2f
            val c = Gold.copy(alpha = p.alpha)
            rotate(p.rot0 + 360f * p.rotSpeed * tt, Offset(px, py)) {
                when (p.type) {
                    0 -> drawCircle(c, h, Offset(px, py), style = stroke)
                    1 -> drawRect(c, Offset(px - h, py - h), Size(s, s), style = stroke)
                    2 -> {
                        val path = Path().apply {
                            moveTo(px, py - h); lineTo(px + h, py + h * 0.8f)
                            lineTo(px - h, py + h * 0.8f); close()
                        }
                        drawPath(path, c, style = stroke)
                    }
                    3 -> {
                        drawLine(c, Offset(px - h, py - h), Offset(px + h, py + h), stroke.width, StrokeCap.Round)
                        drawLine(c, Offset(px - h, py + h), Offset(px + h, py - h), stroke.width, StrokeCap.Round)
                    }
                    4 -> {
                        drawLine(c, Offset(px - h, py), Offset(px + h, py), stroke.width * 1.6f, StrokeCap.Round)
                        drawLine(c, Offset(px, py - h), Offset(px, py + h), stroke.width * 1.6f, StrokeCap.Round)
                    }
                    5 -> {
                        val path = Path().apply {
                            moveTo(px, py - h); lineTo(px + h, py)
                            lineTo(px, py + h); lineTo(px - h, py); close()
                        }
                        drawPath(path, c, style = stroke)
                    }
                    else -> drawCircle(c, s * 0.14f, Offset(px, py))
                }
            }
        }
    }
}

private data class Drop(
    val x: Float, val y0: Float, val speed: Int, val len: Float, val alpha: Float
)

@Composable
fun RainBackground() {
    val drops = remember {
        val r = kotlin.random.Random(5)
        List(70) {
            Drop(
                x = r.nextFloat(), y0 = r.nextFloat(), speed = 2 + r.nextInt(3),
                len = 14f + r.nextFloat() * 18f, alpha = 0.10f + r.nextFloat() * 0.22f
            )
        }
    }
    val transition = rememberInfiniteTransition(label = "rain")
    val t by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(20_000, easing = LinearEasing)),
        label = "rt"
    )
    Canvas(Modifier.fillMaxSize()) {
        val tt = t
        val d = density
        drops.forEach { p ->
            val y = (((p.y0 + p.speed * tt) % 1f) + 1f) % 1f
            val len = p.len * d
            val px = p.x * size.width
            val py = y * (size.height + len) - len
            drawLine(
                Gold.copy(alpha = p.alpha), Offset(px, py), Offset(px, py + len),
                1.4f * d, StrokeCap.Round
            )
        }
    }
}

private data class Doodle(
    val type: Int, val x0: Float, val y0: Float, val dir: Int, val size: Float,
    val rot0: Float, val rotAmp: Float, val amp: Float, val ph: Float, val m: Int,
    val alpha: Float
)

@Composable
fun ChaosBackground() {
    val items = remember {
        val r = kotlin.random.Random(23)
        List(18) { i ->
            Doodle(
                type = i % 3, x0 = r.nextFloat(), y0 = 0.08f + r.nextFloat() * 0.84f,
                dir = if (r.nextBoolean()) 1 else -1, size = 22f + r.nextFloat() * 18f,
                rot0 = -12f + r.nextFloat() * 24f, rotAmp = 6f + r.nextFloat() * 10f,
                amp = 0.02f + r.nextFloat() * 0.04f, ph = r.nextFloat(), m = 1 + r.nextInt(3),
                alpha = 0.18f + r.nextFloat() * 0.22f
            )
        }
    }
    val transition = rememberInfiniteTransition(label = "chaos")
    val t by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(120_000, easing = LinearEasing)),
        label = "ct"
    )
    Canvas(Modifier.fillMaxSize()) {
        val tt = t
        val d = density
        items.forEach { p ->
            val px = ((((p.x0 + p.dir * tt) % 1f) + 1f) % 1f) * size.width
            val py = (p.y0 + p.amp * sin(2.0 * PI * (p.m * tt + p.ph)).toFloat()) * size.height
            val s = p.size * d
            val rot = p.rot0 + p.rotAmp * sin(2.0 * PI * (2 * p.m * tt + p.ph)).toFloat()
            val edge = (min(px, size.width - px) / (90f * d)).coerceIn(0f, 1f)
            val c = Gold.copy(alpha = p.alpha * edge)
            rotate(rot, Offset(px, py)) { drawDoodle(p.type, px, py, s, c) }
        }
    }
}

// Yellow vector versions of a pixel alien, "zzz" and a fight cloud.
private fun DrawScope.drawDoodle(type: Int, cx: Float, cy: Float, s: Float, c: Color) {
    val stroke = Stroke(width = s * 0.09f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    when (type) {
        0 -> {
            val rows = listOf(
                "..X.....X..", "...X...X...", "..XXXXXXX..", ".XX.XXX.XX.",
                "XXXXXXXXXXX", "X.XXXXXXX.X", "X.X.....X.X", "...XX.XX..."
            )
            val cell = s / 11f
            val left = cx - s / 2f
            val top = cy - cell * rows.size / 2f
            rows.forEachIndexed { r, row ->
                row.forEachIndexed { col, ch ->
                    if (ch == 'X') {
                        drawRect(
                            c, Offset(left + col * cell, top + r * cell),
                            Size(cell * 0.92f, cell * 0.92f)
                        )
                    }
                }
            }
        }
        1 -> {
            fun z(x: Float, y: Float, w: Float) {
                val path = Path().apply {
                    moveTo(x, y); lineTo(x + w, y); lineTo(x, y + w); lineTo(x + w, y + w)
                }
                drawPath(path, c, style = stroke)
            }
            z(cx - s * 0.45f, cy + s * 0.05f, s * 0.38f)
            z(cx - s * 0.05f, cy - s * 0.22f, s * 0.30f)
            z(cx + s * 0.25f, cy - s * 0.42f, s * 0.22f)
        }
        else -> {
            val puffs = listOf(
                Triple(-0.30f, 0.06f, 0.20f), Triple(0.00f, -0.10f, 0.28f),
                Triple(0.30f, 0.04f, 0.22f), Triple(-0.10f, 0.14f, 0.22f),
                Triple(0.14f, 0.15f, 0.20f)
            )
            puffs.forEach { (dx, dy, r) ->
                drawCircle(c.copy(alpha = c.alpha * 0.55f), s * r, Offset(cx + dx * s, cy + dy * s))
            }
            val w = stroke.width
            drawLine(c, Offset(cx - 0.34f * s, cy - 0.30f * s), Offset(cx - 0.24f * s, cy - 0.20f * s), w, StrokeCap.Round)
            drawLine(c, Offset(cx - 0.24f * s, cy - 0.30f * s), Offset(cx - 0.34f * s, cy - 0.20f * s), w, StrokeCap.Round)
            drawLine(c, Offset(cx + 0.30f * s, cy - 0.34f * s), Offset(cx + 0.30f * s, cy - 0.22f * s), w, StrokeCap.Round)
            drawLine(c, Offset(cx + 0.24f * s, cy - 0.28f * s), Offset(cx + 0.36f * s, cy - 0.28f * s), w, StrokeCap.Round)
            drawLine(c, Offset(cx - 0.02f * s, cy + 0.34f * s), Offset(cx + 0.06f * s, cy + 0.42f * s), w, StrokeCap.Round)
        }
    }
}

// ------------------------------------------------------------------ Small UI pieces

@Composable
fun SearchField(onQuery: (String) -> Unit, onDone: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .clip(shape)
            .border(1.dp, Gold, shape)
            .background(Gold.copy(alpha = 0.12f))
            .padding(horizontal = 12.dp)
    ) {
        AndroidView(
            modifier = Modifier.width(230.dp).height(38.dp),
            factory = { c ->
                EditText(c).apply {
                    hint = tr("Search apps...")
                    setHintTextColor(0x99FFFFFF.toInt())
                    setTextColor(0xFFFFFFFF.toInt())
                    textSize = 15f
                    setSingleLine(true)
                    background = null
                    inputType = InputType.TYPE_CLASS_TEXT
                    imeOptions = EditorInfo.IME_ACTION_SEARCH or EditorInfo.IME_FLAG_NO_EXTRACT_UI
                    addTextChangedListener(object : TextWatcher {
                        override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                        override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                        override fun afterTextChanged(s: Editable?) { onQuery(s?.toString().orEmpty()) }
                    })
                    setOnEditorActionListener { _, _, _ -> onDone(); true }
                    post {
                        requestFocus()
                        (c.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                            .showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
                    }
                }
            }
        )
    }
}

@Composable
fun Pill(text: String, filled: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    val bg by animateColorAsState(if (filled) Gold else Color.Transparent, tween(220), label = "pillBg")
    Text(
        text,
        color = if (filled) Ink else Gold,
        fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = ls(1f), maxLines = 1,
        modifier = Modifier
            .clip(shape)
            .background(bg)
            .border(1.dp, Gold, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 5.dp)
    )
}

@Composable
fun BigButton(text: String, bg: Color, fg: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Text(
        text, color = fg, fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = ls(1f),
        textAlign = TextAlign.Center, maxLines = 1,
        modifier = Modifier
            .width(240.dp)
            .clip(shape)
            .background(bg)
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp)
    )
}

@Composable
fun TabItem(name: String, active: Boolean, onClick: () -> Unit) {
    val color by animateColorAsState(if (active) Gold else TextDim, tween(250), label = "tabColor")
    val barWidth by animateDpAsState(if (active) 24.dp else 0.dp, tween(300, easing = FastOutSlowInEasing), label = "tabBar")
    Column(
        Modifier
            .clip(RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(name, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = ls(2f), maxLines = 1)
        Box(Modifier.padding(top = 3.dp).height(2.dp).width(barWidth).background(Gold))
    }
}

@Composable
fun GearIcon(open: Boolean, onClick: () -> Unit) {
    val rot by animateFloatAsState(if (open) 90f else 0f, tween(500, easing = FastOutSlowInEasing), label = "gear")
    Canvas(
        Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .padding(8.dp)
            .graphicsLayer { rotationZ = rot }
    ) {
        val s = size.minDimension
        val c = center
        val sw = s * 0.11f
        drawCircle(Gold, s * 0.24f, c, style = Stroke(width = sw))
        drawCircle(Gold, s * 0.07f, c)
        for (i in 0 until 8) {
            val a = i * PI / 4
            val x1 = c.x + (cos(a) * s * 0.34f).toFloat()
            val y1 = c.y + (sin(a) * s * 0.34f).toFloat()
            val x2 = c.x + (cos(a) * s * 0.48f).toFloat()
            val y2 = c.y + (sin(a) * s * 0.48f).toFloat()
            drawLine(Gold, Offset(x1, y1), Offset(x2, y2), s * 0.15f, StrokeCap.Round)
        }
    }
}

@Composable
fun PowerIcon(onClick: () -> Unit) {
    val red = Color(0xFFFF5A5A)
    Canvas(
        Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .padding(9.dp)
    ) {
        val s = size.minDimension
        val sw = s * 0.12f
        drawArc(
            color = red, startAngle = -60f, sweepAngle = 300f, useCenter = false,
            topLeft = Offset(sw / 2f, s * 0.14f + sw / 2f),
            size = Size(s - sw, s * 0.86f - sw),
            style = Stroke(width = sw, cap = StrokeCap.Round)
        )
        drawLine(red, Offset(s / 2f, sw / 2f), Offset(s / 2f, s * 0.5f), sw, StrokeCap.Round)
    }
}

@Composable
fun StarBadge(modifier: Modifier = Modifier) {
    Canvas(modifier.size(20.dp)) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val outer = size.minDimension / 2f
        val inner = outer * 0.42f
        val path = Path()
        for (i in 0 until 10) {
            val r = if (i % 2 == 0) outer else inner
            val a = -PI / 2 + i * PI / 5
            val x = cx + (r * cos(a)).toFloat()
            val y = cy + (r * sin(a)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        drawPath(path, Gold)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppCard(
    app: AppItem,
    index: Int,
    visible: Boolean,
    isSelected: Boolean,
    isFav: Boolean,
    onFocus: () -> Unit,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val enter = remember { Animatable(0f) }
    LaunchedEffect(visible) {
        if (visible) {
            delay((index % 7) * 80L)
            enter.animateTo(1f, tween(600, easing = FastOutSlowInEasing))
        }
    }
    val target = if (pressed) 0.94f else if (isSelected) 1.12f else 1f
    val scale by animateFloatAsState(
        target,
        spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "cardScale"
    )
    val shape = RoundedCornerShape(14.dp)
    Box(
        Modifier
            .graphicsLayer {
                val k = scale * (0.88f + 0.12f * enter.value)
                scaleX = k
                scaleY = k
                alpha = enter.value
                translationY = (1f - enter.value) * 50f
            }
            .width(130.dp)
            .height(175.dp)
            .shadow(if (isSelected) 18.dp else 0.dp, shape, ambientColor = Gold, spotColor = Gold)
            .clip(shape)
            .background(Brush.verticalGradient(listOf(app.tint.copy(alpha = 0.32f), Panel)))
            .border(
                width = if (isSelected) 3.dp else 1.dp,
                color = if (isSelected) Gold else Color(0x26FFFFFF),
                shape = shape
            )
            .onFocusChanged { if (it.isFocused) onFocus() }
            .combinedClickable(
                interactionSource = interaction,
                indication = null,
                onClick = onClick,
                onLongClick = onLongClick
            )
    ) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Image(app.icon, app.label, Modifier.size(80.dp))
            Text(
                app.label, color = Color.White, fontSize = 13.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
            )
        }
        if (isFav) StarBadge(Modifier.align(Alignment.TopEnd).padding(8.dp))
    }
}

// ------------------------------------------------------------------ Sign (6 gaming shapes)

// Shapes: 0 cut corners, 1 arrow tag, 2 hexagon, 3 HUD brackets, 4 pixel box, 5 neon pill.
private fun DrawScope.drawSignShape(style: Int) {
    val w = size.width
    val h = size.height
    val sw = 1.6.dp.toPx()
    val fill = Gold.copy(alpha = 0.12f)
    val line = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)

    fun poly(vararg p: Float): Path {
        val path = Path()
        var i = 0
        while (i < p.size) {
            if (i == 0) path.moveTo(p[i], p[i + 1]) else path.lineTo(p[i], p[i + 1])
            i += 2
        }
        path.close()
        return path
    }

    when (style) {
        0 -> {
            val k = h * 0.32f
            val path = poly(k, 0f, w, 0f, w, h - k, w - k, h, 0f, h, 0f, k)
            drawPath(path, fill)
            drawPath(path, Gold, style = line)
        }
        1 -> {
            val n = h * 0.45f
            val path = poly(0f, 0f, w - n, 0f, w, h / 2f, w - n, h, 0f, h)
            drawPath(path, fill)
            drawPath(path, Gold, style = line)
            drawRect(Gold, Offset.Zero, Size(sw * 2.4f, h))
        }
        2 -> {
            val n = h * 0.5f
            val path = poly(n, 0f, w - n, 0f, w, h / 2f, w - n, h, n, h, 0f, h / 2f)
            drawPath(path, fill)
            drawPath(path, Gold, style = line)
        }
        3 -> {
            drawRect(Gold.copy(alpha = 0.07f), Offset.Zero, Size(w, h))
            val l = h * 0.36f
            val bw = sw * 1.4f
            drawLine(Gold, Offset(0f, l), Offset(0f, 0f), bw, StrokeCap.Round)
            drawLine(Gold, Offset(0f, 0f), Offset(l, 0f), bw, StrokeCap.Round)
            drawLine(Gold, Offset(w - l, 0f), Offset(w, 0f), bw, StrokeCap.Round)
            drawLine(Gold, Offset(w, 0f), Offset(w, l), bw, StrokeCap.Round)
            drawLine(Gold, Offset(w, h - l), Offset(w, h), bw, StrokeCap.Round)
            drawLine(Gold, Offset(w, h), Offset(w - l, h), bw, StrokeCap.Round)
            drawLine(Gold, Offset(l, h), Offset(0f, h), bw, StrokeCap.Round)
            drawLine(Gold, Offset(0f, h), Offset(0f, h - l), bw, StrokeCap.Round)
        }
        4 -> {
            val s = 3.dp.toPx()
            val path = poly(
                2 * s, 0f, w - 2 * s, 0f, w - 2 * s, s, w - s, s, w - s, 2 * s, w, 2 * s,
                w, h - 2 * s, w - s, h - 2 * s, w - s, h - s, w - 2 * s, h - s, w - 2 * s, h,
                2 * s, h, 2 * s, h - s, s, h - s, s, h - 2 * s, 0f, h - 2 * s,
                0f, 2 * s, s, 2 * s, s, s, 2 * s, s
            )
            drawPath(path, fill)
            drawPath(path, Gold, style = Stroke(width = sw * 1.3f, join = StrokeJoin.Miter))
        }
        else -> {
            val r = h / 2f
            val inset = 3.5.dp.toPx()
            drawRoundRect(
                color = Gold.copy(alpha = 0.08f), topLeft = Offset.Zero, size = size,
                cornerRadius = CornerRadius(r, r)
            )
            drawRoundRect(
                color = Gold.copy(alpha = 0.14f), topLeft = Offset(inset, inset),
                size = Size(w - 2 * inset, h - 2 * inset),
                cornerRadius = CornerRadius(r - inset, r - inset),
                style = Stroke(width = 2 * inset)
            )
            drawRoundRect(
                color = Gold, topLeft = Offset(sw / 2f, sw / 2f),
                size = Size(w - sw, h - sw), cornerRadius = CornerRadius(r, r),
                style = Stroke(width = sw)
            )
        }
    }
}

@Composable
fun SignShell(style: Int, text: String) {
    val padH = when (style) {
        1 -> 22.dp
        2 -> 26.dp
        5 -> 22.dp
        else -> 16.dp
    }
    Box(contentAlignment = Alignment.Center) {
        Canvas(Modifier.matchParentSize()) { drawSignShape(style) }
        Text(
            text, color = Gold, fontSize = 14.sp, fontWeight = FontWeight.Bold,
            letterSpacing = ls(1f), maxLines = 1, softWrap = false,
            modifier = Modifier.padding(horizontal = padH, vertical = 8.dp)
        )
    }
}

@Composable
fun SignBadge(st: HomeState) {
    val transition = rememberInfiniteTransition(label = "sign")
    val bob by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(2800, easing = FastOutSlowInEasing), RepeatMode.Reverse
        ),
        label = "signBob"
    )
    if (st.signOn && st.signText.isNotBlank()) {
        Box(
            Modifier.graphicsLayer {
                rotationZ = -2.5f + 5f * bob
                translationY = (0.5f - bob) * 4f
            }
        ) {
            SignShell(st.signStyle, st.signText)
        }
    }
}

@Composable
fun SignEditor(initial: String, onSave: (String) -> Unit, onCancel: () -> Unit) {
    val view = LocalView.current
    val scrimSrc = remember { MutableInteractionSource() }
    val panelSrc = remember { MutableInteractionSource() }
    var draft by remember { mutableStateOf(initial) }
    val shape = RoundedCornerShape(16.dp)
    val fieldShape = RoundedCornerShape(50)
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .clickable(interactionSource = scrimSrc, indication = null, onClick = onCancel),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            Modifier
                .padding(top = 24.dp)
                .clip(shape)
                .background(Panel)
                .border(1.dp, Gold, shape)
                .clickable(interactionSource = panelSrc, indication = null) { }
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                tr("SIGN TEXT"), color = Gold, fontSize = 11.sp,
                fontWeight = FontWeight.Bold, letterSpacing = ls(2f)
            )
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .clip(fieldShape)
                        .border(1.dp, Gold, fieldShape)
                        .background(Gold.copy(alpha = 0.12f))
                        .padding(horizontal = 14.dp)
                ) {
                    AndroidView(
                        modifier = Modifier.width(190.dp).height(40.dp),
                        factory = { c ->
                            EditText(c).apply {
                                hint = tr("Type your sign text")
                                setHintTextColor(0x99FFFFFF.toInt())
                                setTextColor(0xFFFFFFFF.toInt())
                                textSize = 16f
                                setSingleLine(true)
                                background = null
                                inputType = InputType.TYPE_CLASS_TEXT
                                imeOptions = EditorInfo.IME_ACTION_DONE or EditorInfo.IME_FLAG_NO_EXTRACT_UI
                                filters = arrayOf<InputFilter>(InputFilter.LengthFilter(9))
                                setText(initial)
                                setSelection(text.length)
                                addTextChangedListener(object : TextWatcher {
                                    override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                                    override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                                    override fun afterTextChanged(s: Editable?) {
                                        draft = s?.toString().orEmpty()
                                    }
                                })
                                setOnEditorActionListener { _, _, _ ->
                                    hideKeyboard(this)
                                    onSave(draft)
                                    true
                                }
                                post {
                                    requestFocus()
                                    (c.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                                        .showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
                                }
                            }
                        }
                    )
                }
                Spacer(Modifier.width(10.dp))
                Text("${draft.length}/9", color = TextDim, fontSize = 12.sp)
            }
            Spacer(Modifier.height(12.dp))
            Row {
                Pill(tr("CLOSE"), false) { hideKeyboard(view); onCancel() }
                Spacer(Modifier.width(8.dp))
                Pill(tr("DONE"), true) { hideKeyboard(view); onSave(draft) }
            }
        }
    }
}

// ------------------------------------------------------------------ Dialogs & settings

@Composable
fun ExitDialog(onExit: () -> Unit, onStay: () -> Unit) {
    val scrimSrc = remember { MutableInteractionSource() }
    val panelSrc = remember { MutableInteractionSource() }
    val shape = RoundedCornerShape(18.dp)
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .clickable(interactionSource = scrimSrc, indication = null, onClick = onStay),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .clip(shape)
                .background(Panel)
                .border(1.dp, Color(0x33FFFFFF), shape)
                .clickable(interactionSource = panelSrc, indication = null) { }
                .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            BigButton(tr("DO YOU WANT EXIT"), Color(0xFFE53935), Color.White, onExit)
            Spacer(Modifier.height(12.dp))
            BigButton(tr("STAY"), Color.White, Color.Black, onStay)
        }
    }
}

@Composable
fun NavItem(text: String, active: Boolean, onClick: () -> Unit) {
    val color by animateColorAsState(if (active) Gold else TextDim, tween(250), label = "nav")
    val bar by animateDpAsState(if (active) 16.dp else 0.dp, tween(280, easing = FastOutSlowInEasing), label = "navBar")
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 9.dp, horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(3.dp).height(bar).clip(RoundedCornerShape(50)).background(Gold))
        Spacer(Modifier.width(if (active) 8.dp else 11.dp))
        Text(text, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = ls(1f), maxLines = 1)
    }
}

@Composable
fun OptionRow(text: String, selected: Boolean, onClick: () -> Unit) {
    val dot by animateColorAsState(if (selected) Gold else Color.Transparent, tween(220), label = "dot")
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 7.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(10.dp)
                .clip(RoundedCornerShape(50))
                .border(1.5.dp, Gold, RoundedCornerShape(50))
                .background(dot)
        )
        Spacer(Modifier.width(10.dp))
        Text(
            text, color = if (selected) Color.White else TextDim, fontSize = 13.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun SettingCard(title: String, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Color(0x12FFFFFF))
            .border(1.dp, Color(0x1FFFFFFF), shape)
            .padding(12.dp)
    ) {
        Text(title, color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = ls(2f))
        Spacer(Modifier.height(10.dp))
        content()
    }
    Spacer(Modifier.height(10.dp))
}

@Composable
fun SwitchRow(label: String, sub: String, checked: Boolean, onToggle: () -> Unit) {
    val knob by animateDpAsState(if (checked) 23.dp else 3.dp, tween(240, easing = FastOutSlowInEasing), label = "knob")
    val track by animateColorAsState(if (checked) Gold else Color(0xFF3A3A3C), tween(240), label = "track")
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(sub, color = TextDim, fontSize = 11.sp)
        }
        Spacer(Modifier.width(12.dp))
        Box(
            Modifier
                .width(46.dp)
                .height(26.dp)
                .clip(RoundedCornerShape(50))
                .background(track)
                .clickable(onClick = onToggle)
        ) {
            Box(
                Modifier
                    .padding(start = knob, top = 3.dp)
                    .size(20.dp)
                    .clip(RoundedCornerShape(50))
                    .background(if (checked) Ink else Color.White)
            )
        }
    }
}

@Composable
fun SettingsPanel(st: HomeState, act: HomeActions, onEditSign: () -> Unit, onClose: () -> Unit) {
    val scrimSrc = remember { MutableInteractionSource() }
    val panelSrc = remember { MutableInteractionSource() }
    val shape = RoundedCornerShape(18.dp)
    var section by remember { mutableIntStateOf(0) }
    val names = listOf("MUSIC", "BACKGROUND", "THEME", "SIGN", "LANGUAGE")

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xCC000000))
            .clickable(interactionSource = scrimSrc, indication = null, onClick = onClose),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .fillMaxWidth(0.92f)
                .widthIn(max = 700.dp)
                .fillMaxHeight(0.9f)
                .heightIn(max = 320.dp)
                .clip(shape)
                .background(Panel)
                .border(1.dp, Gold, shape)
                .clickable(interactionSource = panelSrc, indication = null) { }
                .padding(18.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text(
                        tr("SETTINGS"), color = Gold, fontSize = 16.sp,
                        fontWeight = FontWeight.Bold, letterSpacing = ls(2f)
                    )
                    Text(tr("Customize deckhome"), color = TextDim, fontSize = 11.sp)
                }
                Spacer(Modifier.weight(1f))
                Pill(tr("CLOSE"), false, onClose)
            }
            Spacer(Modifier.height(12.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x26FFFFFF)))
            Spacer(Modifier.height(12.dp))
            Row(Modifier.weight(1f).fillMaxWidth()) {
                Column(Modifier.width(118.dp).fillMaxHeight()) {
                    names.forEachIndexed { i, n ->
                        NavItem(tr(n), i == section) { act.sfx(SFX_CLICK); section = i }
                    }
                }
                Box(Modifier.width(1.dp).fillMaxHeight().background(Color(0x26FFFFFF)))
                Spacer(Modifier.width(14.dp))
                Box(Modifier.weight(1f).fillMaxHeight()) {
                    Crossfade(targetState = section, animationSpec = tween(260), label = "section") { s ->
                        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                            when (s) {
                                0 -> MusicSection(st, act)
                                1 -> BackgroundSection(st, act)
                                2 -> ThemeSection(st, act)
                                3 -> SignSection(st, act, onEditSign)
                                else -> LanguageSection(st, act)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MusicSection(st: HomeState, act: HomeActions) {
    SettingCard(tr("PLAYBACK")) {
        SwitchRow(tr("Background music"), tr("Plays while deckhome is open"), st.musicOn) {
            act.sfx(SFX_CLICK); act.toggleMusic()
        }
    }
    SettingCard(tr("TRACK")) {
        val names = listOf("Drift", "Dawn", "Midnight", "Glow")
        names.forEachIndexed { i, n ->
            OptionRow(tr(n), st.track == i) { act.sfx(SFX_CLICK); act.chooseTrack(i) }
        }
        OptionRow(
            st.customName?.let { "${tr("Custom")}: $it" } ?: tr("Custom (none yet)"),
            st.track == 4
        ) {
            act.sfx(SFX_CLICK)
            if (st.customName != null) act.chooseTrack(4) else act.pickMusic()
        }
        Spacer(Modifier.height(8.dp))
        Pill(tr("CHOOSE MUSIC FILE"), false) { act.sfx(SFX_CLICK); act.pickMusic() }
    }
}

@Composable
fun BgTile(label: String, selected: Boolean, kind: Int, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(3.dp)
    ) {
        Canvas(
            Modifier
                .size(width = 66.dp, height = 44.dp)
                .clip(shape)
                .background(Color.Black)
                .border(if (selected) 2.dp else 1.dp, if (selected) Gold else Color(0x33FFFFFF), shape)
        ) {
            val w = size.width
            val h = size.height
            val sw = 1.5.dp.toPx()
            val c = Gold.copy(alpha = 0.85f)
            when (kind) {
                0 -> {
                    drawCircle(c, h * 0.13f, Offset(w * 0.25f, h * 0.35f), style = Stroke(width = sw))
                    drawLine(c, Offset(w * 0.55f, h * 0.35f), Offset(w * 0.75f, h * 0.35f), sw, StrokeCap.Round)
                    drawLine(c, Offset(w * 0.65f, h * 0.22f), Offset(w * 0.65f, h * 0.48f), sw, StrokeCap.Round)
                    val tri = Path().apply {
                        moveTo(w * 0.42f, h * 0.84f); lineTo(w * 0.50f, h * 0.62f); lineTo(w * 0.58f, h * 0.84f); close()
                    }
                    drawPath(tri, c, style = Stroke(width = sw, join = StrokeJoin.Round))
                }
                1 -> {
                    for (i in 0 until 6) {
                        val x = w * (0.12f + 0.15f * i)
                        val y0 = h * (0.12f + 0.18f * (i % 3))
                        drawLine(c, Offset(x, y0), Offset(x, y0 + h * 0.28f), sw, StrokeCap.Round)
                    }
                }
                2 -> {
                    val z = Path().apply {
                        moveTo(w * 0.30f, h * 0.30f); lineTo(w * 0.50f, h * 0.30f)
                        lineTo(w * 0.30f, h * 0.62f); lineTo(w * 0.50f, h * 0.62f)
                    }
                    drawPath(z, c, style = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
                    val z2 = Path().apply {
                        moveTo(w * 0.60f, h * 0.20f); lineTo(w * 0.72f, h * 0.20f)
                        lineTo(w * 0.60f, h * 0.40f); lineTo(w * 0.72f, h * 0.40f)
                    }
                    drawPath(z2, c, style = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
                else -> {
                    val mtn = Path().apply {
                        moveTo(w * 0.15f, h * 0.80f); lineTo(w * 0.40f, h * 0.38f)
                        lineTo(w * 0.58f, h * 0.62f); lineTo(w * 0.70f, h * 0.48f)
                        lineTo(w * 0.88f, h * 0.80f); close()
                    }
                    drawPath(mtn, c, style = Stroke(width = sw, join = StrokeJoin.Round))
                    drawCircle(c, h * 0.08f, Offset(w * 0.75f, h * 0.24f), style = Stroke(width = sw))
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            label, color = if (selected) Gold else TextDim, fontSize = 10.sp,
            fontWeight = FontWeight.Bold, maxLines = 1
        )
    }
}

@Composable
fun BackgroundSection(st: HomeState, act: HomeActions) {
    SettingCard(tr("STYLE")) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            BgTile(tr("GAMING"), st.bgMode == 0, 0) { act.sfx(SFX_CLICK); act.chooseBg(0) }
            BgTile(tr("RAIN"), st.bgMode == 1, 1) { act.sfx(SFX_CLICK); act.chooseBg(1) }
            BgTile(tr("CHAOS"), st.bgMode == 3, 2) { act.sfx(SFX_CLICK); act.chooseBg(3) }
            BgTile(tr("PHOTO"), st.bgMode == 2 && st.bgImage != null, 3) {
                act.sfx(SFX_CLICK)
                if (st.bgImage != null) act.chooseBg(2) else act.pickPhoto()
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(tr(HINT_BG), color = TextDim, fontSize = 11.sp)
    }
    SettingCard(tr("YOUR PHOTO")) {
        Pill(tr("CHOOSE PHOTO FROM GALLERY"), false) { act.sfx(SFX_CLICK); act.pickPhoto() }
    }
}

@Composable
fun ThemeSection(st: HomeState, act: HomeActions) {
    SettingCard(tr("COLOR WHEEL")) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ColorWheel(
                selected = st.accent,
                onSelect = { act.sfx(SFX_CLICK); act.chooseAccent(it) },
                modifier = Modifier.size(132.dp)
            )
            Spacer(Modifier.width(16.dp))
            Column {
                Text(
                    tr(ACCENT_NAMES[st.accent.coerceIn(0, ACCENT_NAMES.lastIndex)]),
                    color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold, letterSpacing = ls(2f)
                )
                Spacer(Modifier.height(4.dp))
                Text(tr("Tap a slice to recolor the whole app"), color = TextDim, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun ColorWheel(selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    Canvas(
        modifier.pointerInput(Unit) {
            detectTapGestures { p ->
                val cx = size.width / 2f
                val cy = size.height / 2f
                val dx = p.x - cx
                val dy = p.y - cy
                val r = sqrt(dx * dx + dy * dy)
                val outer = size.width / 2f
                if (r >= outer * 0.30f && r <= outer) {
                    var deg = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat() + 90f
                    deg = ((deg % 360f) + 360f) % 360f
                    onSelect(min(6, (deg / (360f / 7f)).toInt()))
                }
            }
        }
    ) {
        val n = 7
        val seg = 360f / n
        val m = 4.dp.toPx()
        val ring = size.minDimension * 0.30f
        val arcTopLeft = Offset(m + ring / 2f, m + ring / 2f)
        val arcSize = Size(size.minDimension - 2f * m - ring, size.minDimension - 2f * m - ring)
        for (i in 0 until n) {
            val start = -90f + i * seg + 2.5f
            val sweep = seg - 5f
            if (i == selected) {
                drawArc(
                    color = Color.White, startAngle = start, sweepAngle = sweep, useCenter = false,
                    topLeft = arcTopLeft, size = arcSize,
                    style = Stroke(width = ring + 6.dp.toPx())
                )
            }
            drawArc(
                color = ACCENTS[i], startAngle = start, sweepAngle = sweep, useCenter = false,
                topLeft = arcTopLeft, size = arcSize, style = Stroke(width = ring)
            )
        }
        val innerR = (size.minDimension - 2f * m - ring) / 2f - ring / 2f - 3.dp.toPx()
        drawCircle(Color.Black, innerR, center)
        drawCircle(ACCENTS[selected.coerceIn(0, 6)], innerR * 0.45f, center)
    }
}

@Composable
fun SignTile(style: Int, text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        Modifier
            .width(140.dp)
            .height(54.dp)
            .clip(shape)
            .background(Color.Black)
            .border(if (selected) 2.dp else 1.dp, if (selected) Gold else Color(0x33FFFFFF), shape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        SignShell(style, text)
    }
}

@Composable
fun SignSection(st: HomeState, act: HomeActions, onEditSign: () -> Unit) {
    val preview = if (st.signText.isBlank()) "Enjoy" else st.signText
    SettingCard(tr("PREVIEW")) {
        Box(Modifier.fillMaxWidth().height(60.dp), contentAlignment = Alignment.Center) {
            if (st.signOn && st.signText.isNotBlank()) {
                SignShell(st.signStyle, st.signText)
            } else {
                Text(tr("Sign is hidden"), color = TextDim, fontSize = 12.sp)
            }
        }
    }
    SettingCard(tr("SIGN")) {
        SwitchRow(tr("Show sign"), tr("Shown next to the app title"), st.signOn) {
            act.sfx(SFX_CLICK); act.toggleSign()
        }
    }
    SettingCard(tr("SIGN TEXT")) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (st.signText.isBlank()) "-" else st.signText,
                color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, modifier = Modifier.weight(1f)
            )
            Pill(tr("EDIT TEXT"), false) { act.sfx(SFX_CLICK); onEditSign() }
        }
        Spacer(Modifier.height(6.dp))
        Text(tr("Max 9 characters"), color = TextDim, fontSize = 11.sp)
    }
    SettingCard(tr("SIGN STYLE")) {
        for (r in 0 until 3) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (k in 0 until 2) {
                    val i = r * 2 + k
                    SignTile(i, preview, st.signStyle == i) {
                        act.sfx(SFX_CLICK); act.chooseSignStyle(i)
                    }
                }
            }
            if (r < 2) Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
fun LanguageSection(st: HomeState, act: HomeActions) {
    val names = listOf("English", "العربية", "Español", "Français")
    SettingCard(tr("LANGUAGE")) {
        names.forEachIndexed { i, n ->
            OptionRow(n, st.lang == i) { act.sfx(SFX_CLICK); act.chooseLang(i) }
        }
    }
}
